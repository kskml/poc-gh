# Copilot Agent Monitoring — IntelliJ + OpenTelemetry + Grafana

Self-hosted, local-first observability for **GitHub Copilot agents used inside JetBrains IDEs**
(IntelliJ IDEA, PyCharm, GoLand, ...). Clone this repo, run one command, point the *official*
GitHub Copilot plugin's OpenTelemetry settings at this stack, use Copilot Chat in **Agent mode**
for a few minutes — and watch live traces, metrics, logs and a pre-provisioned dashboard appear
in Grafana.

**This repository is receiving infrastructure only.** It contains no plugin code, no
instrumentation, no scraping of the Copilot UI or GitHub APIs, and no cloud dependencies. The
GitHub Copilot JetBrains plugin already embeds the OpenTelemetry SDK and ships an OTel export
settings panel; the entire integration is configuration at the boundaries — three receivers on
one side, three storage backends on the other.

## Architecture

```mermaid
flowchart TB
    subgraph IDE["IntelliJ IDEA"]
        USER["Developer uses Copilot Chat (Agent mode)"]
        PLUGIN["GitHub Copilot Plugin (official, pre-built)
                   Settings: Tools > GitHub Copilot > Chat
                   Contains OTel SDK + embedded Copilot CLI runtime"]
    end

    COLLECTOR["OpenTelemetry Collector (contrib)
               OTLP receiver :4318 HTTP / :4317 gRPC
               Processors: batch, redact
               Exporters: fan-out"]

    subgraph BACKEND["Grafana LGTM Stack"]
        TEMPO["Grafana Tempo (traces, TraceQL)"]
        PROM["Prometheus (metrics, PromQL)"]
        LOKI["Grafana Loki (logs + span events)"]
        GRAF["Grafana (dashboards, alerting)"]
    end

    USER --> PLUGIN
    PLUGIN -- "OTLP/HTTP protobuf :4318" --> COLLECTOR
    COLLECTOR --> TEMPO & PROM & LOKI
    TEMPO & PROM & LOKI --> GRAF
```

| Component | Image | Host ports | Role |
|---|---|---|---|
| OpenTelemetry Collector | `otel/opentelemetry-collector-contrib:latest` (contrib — core lacks the Loki/Prometheus exporters) | 4318, 4317, 8889, 13133 | Receives OTLP, redacts prompt/response content, batches, fans out |
| Grafana Tempo | `grafana/tempo:2.10.8` (pinned — see "Versions & images") | 3200 | Trace storage + TraceQL + span-metrics generator |
| Prometheus | `prom/prometheus:latest` | 9090 | Metric storage (collector exporter + Tempo-generated span metrics) |
| Grafana Loki | `grafana/loki:3.1.1` (3.x required for native OTLP ingestion) | 3100 | Logs + span events |
| Grafana | `grafana/grafana:latest` | 3000 | Dashboards, Explore, alerting |

## Repository layout

```
copilot-otel-monitor/
├── docker-compose.yml          # 5 services on one bridge network (otel-net)
├── otel-collector-config.yaml  # 3 pipelines: traces / metrics / logs + redaction
├── tempo.yaml                  # single-node Tempo, local storage, span metrics
├── prometheus.yml              # scrapes the collector's :8889 exporter
├── loki-config.yaml            # TSDB v13, filesystem, structured metadata on
├── .env.example                # Grafana admin credentials (optional)
├── Makefile                    # up / down / clean / logs / verify
├── README.md
└── grafana/
    ├── provisioning/
    │   ├── datasources/datasources.yaml   # Tempo (default) + Prometheus + Loki
    │   └── dashboards/dashboards.yaml     # loads JSONs into folder "GitHub Copilot"
    └── dashboards/
        └── copilot-agent-monitoring.json  # "GitHub Copilot Agent Monitoring"
```

## Requirements

- Docker Engine 24+ with **Docker Compose v2** (`docker compose ...` must work)
- GNU `make` and `curl` (for `make verify`)
- A JetBrains IDE with the **GitHub Copilot plugin, July 27, 2026 release or newer** (that
  release added the OpenTelemetry export settings)
- Roughly 2 GB of free RAM for the stack

## Quick start

```bash
cp .env.example .env   # optional — admin/admin defaults work out of the box
make up                # starts tempo, prometheus, loki, otel-collector, grafana
make verify            # curls every health endpoint; should print all [PASS]
```

First run pulls ~1 GB of images and takes a few minutes. Once up:

| What | Where |
|---|---|
| Grafana (dashboards) | http://localhost:3000 — login `admin`/`admin`, or anonymous view-only |
| Pre-provisioned dashboard | http://localhost:3000/d/copilot-agent-monitoring |
| Tempo (traces / TraceQL) | http://localhost:3200 |
| Prometheus (metrics) | http://localhost:9090 |
| Loki (logs) | http://localhost:3100 |
| **OTLP endpoint for IntelliJ** | `http://localhost:4318` (protocol `http/protobuf`) |

All state persists in named volumes (`tempo-data`, `prom-data`, `loki-data`, `grafana-data`);
`make clean` removes containers **and** volumes for a full reset.

## Connect IntelliJ

The whole integration happens in the IDE's settings UI:

1. Update the GitHub Copilot plugin in the JetBrains IDE to the latest version
   (OTel export settings shipped in the July 27, 2026 release).
2. Start the stack: `make up`
3. In the IDE: **Settings → Tools → GitHub Copilot → Chat → OpenTelemetry**
4. Set OTLP endpoint: `http://localhost:4318`
5. Set protocol: `http/protobuf` (**note:** the CLI runtime defaults to `http/json`; forcing
   protobuf avoids collector compatibility issues)
6. Leave content capture OFF (the collector redacts anyway as defense-in-depth)
7. Use Copilot Chat in **Agent mode** for a few minutes
8. Open Grafana → the pre-provisioned dashboard

Two things to know:

- **Use Agent mode.** Telemetry flows through the CLI agent harness (`invoke_agent` root
  spans, `execute_tool` children). The legacy local harness is deprecated, and cloud agents
  emit only session counters — plain chat without agent mode produces little or nothing.
- **Force `http/protobuf`.** The collector's OTLP receiver expects protobuf encoding; the
  CLI runtime's `http/json` default is rejected (HTTP 415/400 in collector logs).

## First run: discover your service name

The JetBrains Copilot plugin delegates to the Copilot CLI agent harness, so traces normally
arrive with `service.name = "github-copilot"` — but that value is **not officially documented**
for JetBrains, so treat discovery as a mandatory first-run step.

In Grafana: **Explore → Tempo** (the default datasource) and run:

```tempo
{ } | count_over_time() by (resource.service.name)
```

Expected results:

- `github-copilot` — the CLI runtime default, **most likely for JetBrains**
- `copilot-chat` — the VS Code namespace, unlikely here
- a JetBrains-specific name — possible in future plugin releases

Second query to identify the **agent** — more useful than `service.name` for separating
IntelliJ sessions from terminal CLI sessions, since both may share the runtime:

```tempo
{ resource.service.name = "github-copilot" } | by(span.gen_ai.agent.name)
```

Expected agents: `copilotcli`, `claude`, or a custom agent name. The discovered values are
what you filter dashboards and Explore queries on. Both queries are also embedded in the
"Read me first" panel at the top of the provisioned dashboard.

## What the stack records (data contract)

The plugin's embedded CLI runtime emits OTel signals following the OpenTelemetry GenAI
semantic conventions. One agent interaction produces one trace with this span tree:

```
invoke_agent   (root, gen_ai.operation.name = "invoke_agent")
├── chat          (per LLM call, gen_ai.operation.name = "chat")
├── execute_tool  (per tool call, gen_ai.tool.name = e.g. "readFile")
└── chat          (final response LLM call)
```

Key span attributes: `gen_ai.request.model` / `gen_ai.response.model`,
`gen_ai.usage.input_tokens` / `gen_ai.usage.output_tokens`,
`gen_ai.usage.cache_read.input_tokens` (>0 = cache HIT),
`gen_ai.usage.cache_creation.input_tokens` (>0 = cache MISS),
`gen_ai.agent.name` / `gen_ai.agent.id`, `gen_ai.conversation.id`,
`enduser.pseudo.id`, and `error.type` on failures.

Metrics you will find in Prometheus:

| OTel metric name | Type | Prometheus name (as exported) |
|---|---|---|
| `gen_ai.client.operation.duration` | histogram | `gen_ai_client_operation_duration`, `..._bucket/_sum/_count` |
| `gen_ai.client.token.usage` | histogram | `gen_ai_client_token_usage`, `..._bucket/_sum/_count` |
| `copilot_chat.tool.call.count` | counter | `copilot_chat_tool_call_count` |
| `copilot_chat.agent.invocation.duration` | histogram | `copilot_chat_agent_invocation_duration`, `..._bucket/_sum/_count` |
| `copilot_chat.time_to_first_token` | histogram | `copilot_chat_time_to_first_token`, `..._bucket/_sum/_count` |
| `copilot_chat.session.count` | counter | `copilot_chat_session_count` |

Notes on naming and labels:

- The collector's Prometheus exporter runs with `add_metric_suffixes: false`, so exported
  names match the table above exactly (no extra `_total` / `_seconds` suffixes). Histogram
  `_bucket` / `_sum` / `_count` series always exist by construction.
- `resource_to_telemetry_conversion.enabled: true` promotes resource attributes into metric
  labels — you get `service_name`, `telemetry_pipeline`, etc. on every series. Datapoint
  attributes (`gen_ai_request_model`, `gen_ai_tool_name`, `error_type`) arrive as labels too.
- Tempo's metrics generator additionally derives span metrics (`traces_spanmetrics_calls_total`,
  `traces_spanmetrics_latency_bucket`, dimensions include `gen_ai_operation_name`,
  `gen_ai_request_model`, `gen_ai_agent_name`, `gen_ai_tool_name`, `error_type`) from traces
  and remote-writes them to Prometheus — a second, independent metrics source that the
  dashboard panels use as fallbacks when a plugin metric is not emitted.
- The collector stamps every signal with `telemetry.pipeline = copilot-intellij-monitor`.

## The dashboard

Provisioned into folder **"GitHub Copilot"**, titled **"GitHub Copilot Agent Monitoring"**,
refresh 30s, default range last 3 hours, Prometheus datasource:

| Panel | Type | PromQL (A = plugin metric, B = span-metrics fallback) |
|---|---|---|
| Read me first (discovery + setup + empty-panel triage) | text | — |
| Copilot Sessions rate | stat | A: `sum(rate(copilot_chat_session_count[5m]))` · B: `sum(rate(traces_spanmetrics_calls_total{span_name="invoke_agent"}[5m]))` |
| Token Usage by Model | timeseries | `sum(rate(gen_ai_client_token_usage_sum[5m])) by (gen_ai_request_model)` |
| LLM Call Latency P90 | timeseries | A: `histogram_quantile(0.90, ... gen_ai_client_operation_duration_bucket ...)` · B: `... traces_spanmetrics_latency_bucket{span_name="chat"} ...` |
| Tool Calls by Tool | timeseries (bars) | A: `sum(rate(copilot_chat_tool_call_count[5m])) by (gen_ai_tool_name)` · B: `... traces_spanmetrics_calls_total{span_name="execute_tool"} ... by (gen_ai_tool_name)` |
| Agent Invocation Duration P50/P90 | timeseries | A/B: `copilot_chat_agent_invocation_duration_bucket` · C/D: `traces_spanmetrics_latency_bucket{span_name="invoke_agent"}` |
| Time to First Token P90 | timeseries | `copilot_chat_time_to_first_token_bucket` only — no trace-derived fallback exists for this timing |
| Errors by Type | timeseries | A: `copilot_chat_tool_call_count{error_type!=""}` · B: `traces_spanmetrics_calls_total{status_code="STATUS_CODE_ERROR"}` by (error_type) |
| Recent traces (bonus) | table (Tempo) | live trace list as soon as OTLP flows |

Why two targets per panel: the `copilot_chat_*` plugin metrics are **not guaranteed** —
availability varies with agent mode, cloud vs local runs, and plugin version. The
span-metrics targets are derived by Tempo from the traces themselves (official 2.x names:
`traces_spanmetrics_calls_total`, `traces_spanmetrics_latency_bucket`), so they render
whenever traces flow. `gen_ai.tool.name` and `error.type` are exported as span-metrics
dimensions (`gen_ai_tool_name`, `error_type` labels) for exactly this purpose. Check which
metric names actually exist in your stack at
<http://localhost:9090/api/v1/label/__name__/values> (search `gen_ai`, `copilot`,
`traces_spanmetrics`).

Panels stay empty until IntelliJ traffic arrives — that is expected. Once you use Copilot
Chat in Agent mode, data appears within ~30 seconds.

## Verification checklist

1. `make verify` — all six checks green (collector health :13133, tempo :3200/ready,
   prometheus healthy, prometheus scraping `otel-collector:8889`, loki :3100/ready, grafana).
2. **Traces:** Grafana → Explore → Tempo:

   ```tempo
   { resource.service.name = "github-copilot" && span.gen_ai.operation.name = "invoke_agent" }
   ```

   Open a trace and confirm the span tree (`invoke_agent` → `chat` / `execute_tool`), model
   names, token counts, and the node graph.
3. **Metrics:** Grafana → Explore → Prometheus:

   ```promql
   up{job="otel-collector"}
   sum(rate(copilot_chat_session_count[5m]))
   sum(rate(gen_ai_client_token_usage_sum[5m])) by (gen_ai_request_model)
   ```

   Also check http://localhost:9090/targets — `otel-collector:8889` must be **UP**.
4. **Logs:** Grafana → Explore → Loki, query `{service_name="github-copilot"}` (adjust to your
   discovered value). Log records and span events arrive via Loki's native OTLP endpoint.
5. **Pipeline activity:** `make logs` shows the collector receiving OTLP batches continuously.

## Privacy & redaction (defense in depth)

Two independent layers prevent prompt/response content from ever being stored:

1. **Plugin setting off** — content capture stays disabled in the IDE (step 6 above).
2. **Collector redaction** — `attributes/redact-content` deletes these attribute keys from
   spans and log records *before* export, so even an accidentally enabled capture setting
   leaks nothing into Tempo or Loki:
   - `gen_ai.input.messages`
   - `gen_ai.output.messages`
   - `gen_ai.system_instructions`
   - `gen_ai.tool.call.arguments`
   - `gen_ai.tool.call.result`
   - `gen_ai.tool.definitions`

What is still recorded (by design): latencies, token counts, cache hit/miss indicators, model
names, tool names, agent identity, conversation ids, `enduser.pseudo.id`, and error types —
enough to reason about behavior, not content.

**How to verify the redaction works:**

1. Temporarily switch content capture **ON** in the plugin (yes, on purpose).
2. Use Copilot Agent mode for a couple of interactions.
3. Grafana → Explore → Tempo → open a `chat` span → inspect its attributes:
   `gen_ai.input.messages` and `gen_ai.output.messages` must **not** appear.
4. Optionally uncomment the `debug` exporter in `otel-collector-config.yaml`, add `debug` to
   the traces/metrics/logs pipeline exporters, and run `make logs` — the printed batches show
   the attributes are already gone at the collector stage.
5. Switch content capture back **OFF**.

## Troubleshooting

| Symptom | Check / fix |
|---|---|
| Nothing anywhere in Grafana | Run `make logs` — is the collector printing received OTLP batches? Confirm the IDE endpoint is `http://localhost:4318` and protocol is `http/protobuf`. Confirm you used **Agent mode**. |
| Collector fails to start ("dependency failed to start: container tempo is unhealthy") | Run `docker compose logs tempo`. If you see `field ingester not found in type app.Config` (same for `compactor`), you are running **Tempo 3.x** — 3.0 (Jun 2026) removed the top-level `ingester`/`compactor` config blocks. This repo pins `grafana/tempo:2.10.8`, which matches `tempo.yaml`; keep the pin (or run `tempo-cli migrate config` first if you deliberately move to 3.x). Tempo deliberately has **no in-container healthcheck**: the image is distroless (no shell, no wget/curl) and the binary has no health command — readiness is checked from the host by `make verify` (`curl localhost:3200/ready`). The **loki image is Alpine-based** and ships busybox wget for its probe. Diagnose with `docker compose ps` and `docker compose logs tempo loki`. |
| Only some dashboard panels show data (e.g. Token Usage + Recent traces) | Not an ingestion fault: the empty panels read `copilot_chat_*` plugin metrics your runtime does not emit in the current mode/version (they are not part of the guaranteed GenAI semconv). Open http://localhost:9090/api/v1/label/__name__/values and search `copilot` / `gen_ai` / `traces_spanmetrics` to see what exists. Every panel also carries a **span-metrics fallback** (legend "(span metrics)") derived from traces — if those are empty too, see the "Nothing anywhere in Grafana" row. The TTFT panel has no fallback by nature. |
| Span-metrics fallback panels stay empty while traces are visible | Tempo derives them only from traces arriving **after** the current `tempo.yaml` dimension set was loaded. If you changed dimensions, restart the trace path: `docker compose restart tempo` (older spans keep their old label set). Then re-check after the next agent interaction. |
| Traces visible, **metrics missing** | The collector config must keep all three pipelines — a traces-only pipeline config silently drops metrics. Then check http://localhost:9090/targets: `otel-collector:8889` must be UP (first scrape ~15s after traffic). |
| Metrics exist but have no labels | `resource_to_telemetry_conversion.enabled: true` must be set on the `prometheus` exporter (it is, by default, in this repo). |
| Metric names differ (`..._total`, `..._seconds`) | The exporter must run with `add_metric_suffixes: false` (it is, by default, in this repo) so names match the dashboard PromQL. |
| Collector logs show HTTP 415/400 rejections | Protocol mismatch — the plugin is exporting `http/json` (the CLI runtime default). Set protocol to `http/protobuf` in the IDE settings. |
| Loki rejects log exports | Must run Loki **3.x** with `allow_structured_metadata: true` — both are configured here (image pinned to `grafana/loki:3.1.1`). |
| Log exporter errors at collector startup | The logs pipeline must use the **`otlphttp`** exporter (`endpoint: http://loki:3100/otlp`). Loki's native OTLP endpoint is HTTP-only; the gRPC `otlp` exporter cannot dial that URL. |
| `service.name` unknown / unexpected | Run the discovery TraceQL query from the section above (and the "Read me first" dashboard panel); filter on the value you actually see. |
| No telemetry from plain (non-agent) chat | Expected — telemetry is emitted by the CLI agent harness. Use **Agent mode**. Cloud agents emit only session counters; the local harness is deprecated. |
| Port already in use | Edit the host-side port in `docker-compose.yml` (left side of the mapping). Keep container-side ports unchanged, then update the IDE endpoint if you moved 4318. |
| Want a full reset | `make clean` removes containers and all four data volumes. |
| Need to poke inside a container | Grafana/Loki/Prometheus/collector images have a shell. **Tempo is distroless** — `docker compose exec tempo sh` fails by design; use `docker compose logs tempo` instead. |

## Makefile targets

| Target | What it does |
|---|---|
| `make up` | `docker compose up -d`, then prints every URL and next steps |
| `make down` | Stops the stack, keeps data volumes |
| `make clean` | Stops the stack **and** deletes all volumes (`down -v`) |
| `make logs` | Tails collector logs — watch OTLP batches arrive |
| `make verify` | Curls collector :13133, tempo :3200/ready, prometheus health + targets, loki :3100/ready, grafana :3000/api/health; exits non-zero on any failure |

## Versions & images

| Image | Tag | Requirement |
|---|---|---|
| `otel/opentelemetry-collector-contrib` | `latest` | **contrib** build, not core (core lacks Loki/Prometheus exporters) |
| `grafana/tempo` | `2.10.8` | **Pinned**: Tempo 3.0 (Jun 2026) removed the `ingester`/`compactor` config blocks `tempo.yaml` uses; 2.10.8 is the final 2.x release |
| `grafana/loki` | `3.1.1` | 3.x pinned — required for native OTLP ingestion |
| `prom/prometheus` | `latest` | `--web.enable-remote-write-receiver` enabled for Tempo span metrics |
| `grafana/grafana` | `latest` | — |

Tempo is deliberately pinned: 3.0 is config-incompatible with this repo (see the troubleshooting table). The remaining `latest` tags track upstream updates; if you need reproducible builds, pin them too and re-test — especially the collector, since exporter/processor options evolve. To move to Tempo 3.x, migrate the config first (`tempo-cli migrate config`) and re-pin.

## References

- OTel GenAI Semantic Conventions — https://github.com/open-telemetry/semantic-conventions-genai
- GitHub Copilot CLI command reference (OTel section: env vars, span schema) —
  https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-command-reference
- Reference implementation (inspiration, not required) — https://github.com/webmaxru/copilot-opentelemetry
- IntelliJ OTel feature changelog (July 27, 2026) —
  https://github.blog/changelog/2026-07-27-github-copilot-for-jetbrains-adds-improvved-opentelemetry-configuration-and-model-management
- Tempo configuration — https://grafana.com/docs/tempo/latest/configuration
- Loki OTLP ingestion — https://grafana.com/docs/loki/latest/send-data/otlp
