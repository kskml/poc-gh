# OpenCode Telemetry Dashboard

A full-stack telemetry dashboard that tracks your opencode AI usage: sessions, messages, token
consumption, estimated cost, and tool usage. It reads directly from opencode's own SQLite database
(`~/.local/share/opencode/opencode.db`), so there is no agent or exporter to install — point, run, watch.

## Architecture

```mermaid
graph LR
    A["opencode.db (SQLite)"] --> B["Express API (port 3001)"]
    B --> C["Aggregated JSON endpoints /api/*"]
    C --> D["Vite dev server (port 5173)"]
    D --> E["React + Chart.js dashboard"]
    D -- "/api proxy" --> B
```

```
opencode-telemetry/
├── package.json          # npm workspaces + top-level scripts
├── server/               # backend (Node 22, node:sqlite, Express)
│   ├── src/
│   │   ├── index.js      # app entry, listens on :3001
│   │   ├── config.js     # env config + DB path resolution
│   │   ├── store.js      # read-only SQLite wrapper (node:sqlite)
│   │   ├── routes.js     # REST API routes
│   │   ├── queries.js    # aggregation queries over opencode schema
│   │   └── seed.js       # generates a rich demo dataset (server/data/demo.db)
│   └── data/             # generated demo.db (gitignored)
└── web/                  # frontend (React + Vite + Chart.js)
    ├── vite.config.js    # /api proxy → :3001, allowedHosts
    └── src/
        ├── App.jsx
        ├── api.js
        ├── chartSetup.js
        ├── hooks/useFetch.js
        ├── utils.js
        └── components/   # KPI cards, charts, tables
```

## Why Node 22?

The backend uses the built-in `node:sqlite` module — zero native dependencies, no better-sqlite3
compilation. Requires Node `>=22.5.0`.

## Quick start

```bash
npm install

# (optional) generate a rich demo dataset, then serve it
npm run seed
OPENCODE_DB_PATH=./server/data/demo.db npm run server

# in another terminal
npm run web
```

Open the dashboard at `http://localhost:5173`.

### Run both with one command

```bash
npm run dev
```

This starts the backend and the frontend together.

## Configuration

| Env var              | Default                                        | Purpose                                  |
| -------------------- | ---------------------------------------------- | ---------------------------------------- |
| `OPENCODE_DB_PATH`   | `~/.local/share/opencode/opencode.db`          | SQLite database to read telemetry from    |
| `PORT`               | `3001`                                         | Backend port                             |

If `OPENCODE_DB_PATH` is unset and the real opencode DB is missing, the backend falls back to
`server/data/demo.db` (if it exists). `npm run seed` creates that demo DB with ~22 sessions across
30 days of realistic activity.

## REST API

All endpoints are read-only and served under `/api`.

| Endpoint                         | Description                                        |
| -------------------------------- | -------------------------------------------------- |
| `GET /api/health`                | Backend health + active DB path                    |
| `GET /api/stats`                 | Global KPIs (sessions, messages, tokens, cost…)    |
| `GET /api/timeseries`            | Bucketed usage; `?days=30&granularity=day\|hour`    |
| `GET /api/models`                | Per-model messages, tokens, cost, sessions         |
| `GET /api/agents`                | Per-agent messages, tokens, cost                   |
| `GET /api/tools`                 | Per-tool calls, success rate, avg duration         |
| `GET /api/sessions?limit=50`     | Recent sessions with per-session metrics           |
| `GET /api/messages?limit=100`    | Recent messages with role, model, cost, tokens     |

## Dashboard panels

- KPI cards: sessions, messages, total tokens, estimated cost, tool calls, text output
- Usage over time (area chart: cache-read / input / output / reasoning tokens, 7/14/30/90-day range)
- Cost & tokens by model (dual-axis bar) and cost share (donut)
- Messages & tokens by agent
- Tool usage table (calls, success rate, avg duration)
- Recent sessions table

## How the data maps to opencode's schema

| Dashboard metric      | Source                                     |
| --------------------- | ------------------------------------------ |
| Sessions, cost        | `session` (`cost`, `tokens_*`, `model`)    |
| Messages, tokens      | `message` (`data.role`, `data.tokens`)     |
| Tool calls, durations | `part` (`data.type="tool"`, `time.start/end`) |
| Text / reasoning chars| `part` (`data.type="text"|"reasoning"`)    |

Cost is estimated from per-model token pricing (input/output/cache read/cache write) recorded in
message data, summed across the dataset. Cache-token charges dominate total token counts, which is
expected — opencode aggressively reuses context.
