import os from "node:os";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const DEFAULT_OPENCODE_DB = path.join(
  os.homedir(),
  ".local",
  "share",
  "opencode",
  "opencode.db",
);

export function resolveDbPath(env = process.env) {
  const fromEnv = env.OPENCODE_DB_PATH;
  if (fromEnv) {
    return path.resolve(fromEnv);
  }
  if (fs.existsSync(DEFAULT_OPENCODE_DB)) {
    return DEFAULT_OPENCODE_DB;
  }
  const demoDb = path.join(__dirname, "..", "data", "demo.db");
  if (fs.existsSync(demoDb)) {
    return demoDb;
  }
  return DEFAULT_OPENCODE_DB;
}

export const config = {
  port: Number(process.env.PORT || 3001),
  dbPath: resolveDbPath(),
  demoDbPath: path.join(__dirname, "..", "data", "demo.db"),
};
