import express from "express";
import cors from "cors";
import { config } from "./config.js";
import { openStore } from "./store.js";
import routes from "./routes.js";

const app = express();
app.use(cors());
app.use(express.json());

openStore(config.dbPath);
app.use("/api", routes);

app.use((req, res) => {
  res.status(404).json({ error: "Not found" });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message });
});

app.listen(config.port, () => {
  console.log(`[telemetry] listening on http://localhost:${config.port}`);
  console.log(`[telemetry] reading database: ${config.dbPath}`);
});
