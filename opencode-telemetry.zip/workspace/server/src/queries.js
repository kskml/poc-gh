import { getDb, parseJson } from "./store.js";

const DAY_MS = 24 * 60 * 60 * 1000;

function iso(ts) {
  return ts ? new Date(ts).toISOString() : null;
}

function fmtMoney(cost) {
  return typeof cost === "number" ? Number(cost.toFixed(4)) : Number(cost || 0);
}

function bucketKey(ts, granularity) {
  const d = new Date(ts);
  if (granularity === "hour") {
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}T${String(d.getUTCHours()).padStart(2, "0")}:00:00.000Z`;
  }
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}T00:00:00.000Z`;
}

function normalizeModel(msgData, session) {
  let modelID = msgData?.modelID || msgData?.model?.id;
  let providerID = msgData?.providerID || msgData?.model?.providerID;
  if (!modelID && session) {
    const sm = parseJson(session.model);
    modelID = sm?.id;
    providerID = sm?.providerID;
  }
  return { modelID: modelID || "unknown", providerID: providerID || "unknown" };
}

export function getStats() {
  const db = getDb();
  const sessions = db
    .prepare("SELECT id, model, cost, time_created, time_updated FROM session")
    .all();
  const messages = db
    .prepare("SELECT session_id, time_created, data FROM message")
    .all();
  const parts = db.prepare("SELECT data FROM part").all();

  const sessionById = new Map(sessions.map((s) => [s.id, s]));

  const stats = {
    sessions: sessions.length,
    messages: messages.length,
    userMessages: 0,
    assistantMessages: 0,
    toolCalls: 0,
    tools: 0,
    tokensInput: 0,
    tokensOutput: 0,
    tokensReasoning: 0,
    tokensCacheRead: 0,
    tokensCacheWrite: 0,
    cost: 0,
    textChars: 0,
    reasoningChars: 0,
    activeDays: 0,
    models: new Set(),
    agents: new Set(),
    toolNames: new Set(),
    firstSeen: null,
    lastSeen: null,
  };

  for (const m of messages) {
    const d = parseJson(m.data);
    if (!d) continue;
    const role = d.role;
    if (role === "user") stats.userMessages++;
    else if (role === "assistant") stats.assistantMessages++;
    const t = d.tokens || {};
    stats.tokensInput += t.input || 0;
    stats.tokensOutput += t.output || 0;
    stats.tokensReasoning += t.reasoning || 0;
    stats.tokensCacheRead += t.cache?.read || 0;
    stats.tokensCacheWrite += t.cache?.write || 0;
    stats.cost += d.cost || 0;
    const { modelID, providerID } = normalizeModel(d, sessionById.get(m.session_id));
    stats.models.add(`${providerID}:${modelID}`);
    if (d.agent) stats.agents.add(d.agent);
    const ts = d.time?.created || m.time_created;
    if (ts) {
      if (stats.firstSeen === null || ts < stats.firstSeen) stats.firstSeen = ts;
      if (stats.lastSeen === null || ts > stats.lastSeen) stats.lastSeen = ts;
    }
  }

  for (const p of parts) {
    const d = parseJson(p.data);
    if (!d) continue;
    if (d.type === "text" && d.text) stats.textChars += d.text.length;
    if (d.type === "reasoning" && d.text) stats.reasoningChars += d.text.length;
    if (d.type === "tool" && d.tool) {
      stats.toolCalls++;
      stats.toolNames.add(d.tool);
    }
  }

  const daySet = new Set();
  for (const m of messages) {
    const d = parseJson(m.data);
    const ts = d?.time?.created || m.time_created;
    if (ts) daySet.add(bucketKey(ts, "day"));
  }

  return {
    sessions: stats.sessions,
    messages: stats.messages,
    userMessages: stats.userMessages,
    assistantMessages: stats.assistantMessages,
    toolCalls: stats.toolCalls,
    tools: stats.toolNames.size,
    tokensInput: stats.tokensInput,
    tokensOutput: stats.tokensOutput,
    tokensReasoning: stats.tokensReasoning,
    tokensCacheRead: stats.tokensCacheRead,
    tokensCacheWrite: stats.tokensCacheWrite,
    cost: fmtMoney(stats.cost),
    textChars: stats.textChars,
    reasoningChars: stats.reasoningChars,
    activeDays: daySet.size,
    models: stats.models.size,
    agents: stats.agents.size,
    totalTokens:
      stats.tokensInput +
      stats.tokensOutput +
      stats.tokensReasoning +
      stats.tokensCacheRead +
      stats.tokensCacheWrite,
    firstSeen: iso(stats.firstSeen),
    lastSeen: iso(stats.lastSeen),
  };
}

export function getTimeseries({ granularity, days } = {}) {
  const db = getDb();
  const now = Date.now();
  const rangeMs = days && days > 0 ? days * DAY_MS : 30 * DAY_MS;
  const since = now - rangeMs;

  const messages = db
    .prepare("SELECT session_id, time_created, data FROM message WHERE time_created >= ?")
    .all(since);
  const parts = db
    .prepare("SELECT time_created, data FROM part WHERE time_created >= ?")
    .all(since);
  const sessionById = new Map(
    db.prepare("SELECT id, model FROM session").all().map((s) => [s.id, s]),
  );

  const granularity_ = granularity === "hour" ? "hour" : "day";
  const buckets = new Map();

  for (const m of messages) {
    const d = parseJson(m.data);
    if (!d) continue;
    const ts = d.time?.created || m.time_created;
    if (ts < since) continue;
    const key = bucketKey(ts, granularity_);
    let b = buckets.get(key);
    if (!b) {
      b = {
        ts: key,
        messages: 0,
        toolCalls: 0,
        tokensInput: 0,
        tokensOutput: 0,
        tokensReasoning: 0,
        tokensCacheRead: 0,
        tokensCacheWrite: 0,
        cost: 0,
      };
      buckets.set(key, b);
    }
    b.messages++;
    const t = d.tokens || {};
    b.tokensInput += t.input || 0;
    b.tokensOutput += t.output || 0;
    b.tokensReasoning += t.reasoning || 0;
    b.tokensCacheRead += t.cache?.read || 0;
    b.tokensCacheWrite += t.cache?.write || 0;
    b.cost += d.cost || 0;
  }

  for (const p of parts) {
    const d = parseJson(p.data);
    if (!d || d.type !== "tool" || !d.tool) continue;
    const ts = d.time?.start || p.time_created;
    if (ts < since) continue;
    const key = bucketKey(ts, granularity_);
    let b = buckets.get(key);
    if (!b) {
      b = {
        ts: key,
        messages: 0,
        toolCalls: 0,
        tokensInput: 0,
        tokensOutput: 0,
        tokensReasoning: 0,
        tokensCacheRead: 0,
        tokensCacheWrite: 0,
        cost: 0,
      };
      buckets.set(key, b);
    }
    b.toolCalls++;
  }

  return [...buckets.values()]
    .map((b) => ({ ...b, cost: fmtMoney(b.cost) }))
    .sort((a, b) => a.ts.localeCompare(b.ts));
}

export function getModels() {
  const db = getDb();
  const sessions = db
    .prepare("SELECT id, model FROM session")
    .all();
  const sessionById = new Map(sessions.map((s) => [s.id, s]));
  const messages = db.prepare("SELECT session_id, data FROM message").all();

  const map = new Map();
  for (const m of messages) {
    const d = parseJson(m.data);
    if (!d) continue;
    const { modelID, providerID } = normalizeModel(d, sessionById.get(m.session_id));
    const key = `${providerID}/${modelID}`;
    let e = map.get(key);
    if (!e) {
      e = {
        model: modelID,
        provider: providerID,
        messages: 0,
        tokensInput: 0,
        tokensOutput: 0,
        tokensReasoning: 0,
        tokensCacheRead: 0,
        tokensCacheWrite: 0,
        cost: 0,
        sessions: new Set(),
      };
      map.set(key, e);
    }
    e.messages++;
    e.sessions.add(m.session_id);
    const t = d.tokens || {};
    e.tokensInput += t.input || 0;
    e.tokensOutput += t.output || 0;
    e.tokensReasoning += t.reasoning || 0;
    e.tokensCacheRead += t.cache?.read || 0;
    e.tokensCacheWrite += t.cache?.write || 0;
    e.cost += d.cost || 0;
  }

  return [...map.values()]
    .map((e) => ({
      model: e.model,
      provider: e.provider,
      messages: e.messages,
      sessions: e.sessions.size,
      tokensInput: e.tokensInput,
      tokensOutput: e.tokensOutput,
      tokensReasoning: e.tokensReasoning,
      tokensCacheRead: e.tokensCacheRead,
      tokensCacheWrite: e.tokensCacheWrite,
      tokensTotal:
        e.tokensInput + e.tokensOutput + e.tokensReasoning + e.tokensCacheRead + e.tokensCacheWrite,
      cost: fmtMoney(e.cost),
    }))
    .sort((a, b) => b.cost - a.cost || b.tokensTotal - a.tokensTotal);
}

export function getAgents() {
  const db = getDb();
  const sessions = db.prepare("SELECT id, model FROM session").all();
  const sessionById = new Map(sessions.map((s) => [s.id, s]));
  const messages = db.prepare("SELECT session_id, data FROM message").all();

  const map = new Map();
  for (const m of messages) {
    const d = parseJson(m.data);
    if (!d) continue;
    const agent = d.agent || "unknown";
    let e = map.get(agent);
    if (!e) {
      e = { agent, messages: 0, tokensInput: 0, tokensOutput: 0, cost: 0, sessions: new Set() };
      map.set(agent, e);
    }
    e.messages++;
    e.sessions.add(m.session_id);
    const t = d.tokens || {};
    e.tokensInput += t.input || 0;
    e.tokensOutput += t.output || 0;
    e.cost += d.cost || 0;
  }

  return [...map.values()]
    .map((e) => ({
      ...e,
      sessions: e.sessions.size,
      tokensTotal: e.tokensInput + e.tokensOutput,
      cost: fmtMoney(e.cost),
    }))
    .sort((a, b) => b.cost - a.cost);
}

export function getTools() {
  const db = getDb();
  const parts = db.prepare("SELECT data FROM part").all();

  const map = new Map();
  for (const p of parts) {
    const d = parseJson(p.data);
    if (!d || d.type !== "tool" || !d.tool) continue;
    let e = map.get(d.tool);
    if (!e) {
      e = { tool: d.tool, calls: 0, success: 0, failed: 0, totalMs: 0 };
      map.set(d.tool, e);
    }
    e.calls++;
    const status = d.state?.status;
    if (status === "completed") e.success++;
    else if (status === "error" || status === "failed") e.failed++;
    const start = d.time?.start;
    const end = d.time?.end;
    if (start && end && end >= start) e.totalMs += end - start;
  }

  return [...map.values()]
    .map((e) => ({
      tool: e.tool,
      calls: e.calls,
      success: e.success,
      failed: e.failed,
      successRate: e.calls ? Number(((e.success / e.calls) * 100).toFixed(1)) : 0,
      avgMs: e.calls ? Math.round(e.totalMs / e.calls) : 0,
    }))
    .sort((a, b) => b.calls - a.calls);
}

export function getSessions({ limit } = {}) {
  const db = getDb();
  const limitN = Math.min(Math.max(limit || 50, 1), 500);
  const sessions = db
    .prepare(
      `SELECT id, project_id, title, agent, model, cost,
              tokens_input, tokens_output, tokens_reasoning,
              tokens_cache_read, tokens_cache_write,
              time_created, time_updated
       FROM session ORDER BY time_created DESC LIMIT ?`,
    )
    .all(limitN);

  const ids = sessions.map((s) => s.id);
  const placeholders = ids.map(() => "?").join(",");
  const msgCounts = new Map();
  const toolCounts = new Map();
  if (ids.length) {
    const msgRows = db
      .prepare(`SELECT session_id, COUNT(*) AS c FROM message WHERE session_id IN (${placeholders}) GROUP BY session_id`)
      .all(...ids);
    for (const r of msgRows) msgCounts.set(r.session_id, r.c);
    const partRows = db
      .prepare(`SELECT session_id, data FROM part WHERE session_id IN (${placeholders})`)
      .all(...ids);
    for (const r of partRows) {
      const d = parseJson(r.data);
      if (d && d.type === "tool" && d.tool) {
        toolCounts.set(r.session_id, (toolCounts.get(r.session_id) || 0) + 1);
      }
    }
  }

  return sessions.map((s) => {
    const sm = parseJson(s.model);
    return {
      id: s.id,
      title: s.title || "Untitled session",
      agent: s.agent,
      model: sm?.id || "unknown",
      provider: sm?.providerID || "unknown",
      cost: fmtMoney(s.cost),
      tokensInput: s.tokens_input || 0,
      tokensOutput: s.tokens_output || 0,
      tokensReasoning: s.tokens_reasoning || 0,
      tokensCacheRead: s.tokens_cache_read || 0,
      tokensCacheWrite: s.tokens_cache_write || 0,
      messages: msgCounts.get(s.id) || 0,
      toolCalls: toolCounts.get(s.id) || 0,
      timeCreated: iso(s.time_created),
      timeUpdated: iso(s.time_updated),
      durationMs: s.time_updated && s.time_created ? s.time_updated - s.time_created : null,
    };
  });
}

export function getMessages({ limit } = {}) {
  const db = getDb();
  const limitN = Math.min(Math.max(limit || 100, 1), 1000);
  const messages = db
    .prepare("SELECT session_id, time_created, data FROM message ORDER BY time_created DESC LIMIT ?")
    .all(limitN);
  return messages.map((m) => {
    const d = parseJson(m.data) || {};
    const t = d.tokens || {};
    return {
      id: m.id,
      sessionId: m.session_id,
      role: d.role || "unknown",
      agent: d.agent || null,
      model: d.modelID || null,
      finish: d.finish || null,
      cost: fmtMoney(d.cost),
      tokensInput: t.input || 0,
      tokensOutput: t.output || 0,
      tokensReasoning: t.reasoning || 0,
      timeCreated: iso(d.time?.created || m.time_created),
      timeCompleted: iso(d.time?.completed || null),
    };
  });
}
