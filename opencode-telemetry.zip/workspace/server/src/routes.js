import { Router } from "express";
import {
  getStats,
  getTimeseries,
  getModels,
  getAgents,
  getTools,
  getSessions,
  getMessages,
} from "./queries.js";
import { config } from "./config.js";

const router = Router();

const wrap = (fn) => (req, res) => {
  try {
    const result = fn(req, res);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

router.get(
  "/health",
  wrap(() => ({ ok: true, db: config.dbPath })),
);

router.get(
  "/stats",
  wrap(() => getStats()),
);

router.get(
  "/timeseries",
  wrap((req) => {
    const granularity = req.query.granularity === "hour" ? "hour" : "day";
    const days = Number.parseInt(req.query.days, 10) || 30;
    return getTimeseries({ granularity, days });
  }),
);

router.get(
  "/models",
  wrap(() => getModels()),
);

router.get(
  "/agents",
  wrap(() => getAgents()),
);

router.get(
  "/tools",
  wrap(() => getTools()),
);

router.get(
  "/sessions",
  wrap((req) => {
    const limit = Number.parseInt(req.query.limit, 10) || 50;
    return getSessions({ limit });
  }),
);

router.get(
  "/messages",
  wrap((req) => {
    const limit = Number.parseInt(req.query.limit, 10) || 100;
    return getMessages({ limit });
  }),
);

export default router;
