import { DatabaseSync } from "node:sqlite";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { config } from "./config.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const MODELS = [
  { id: "claude-sonnet-4", provider: "anthropic", inPerM: 3, outPerM: 15, cacheReadPerM: 0.3, cacheWritePerM: 3.75 },
  { id: "deepseek-v4", provider: "monkeycode-ai", inPerM: 0.3, outPerM: 1.2, cacheReadPerM: 0.07, cacheWritePerM: 0.3 },
  { id: "gpt-5", provider: "openai", inPerM: 1.25, outPerM: 10, cacheReadPerM: 0.1, cacheWritePerM: 1.25 },
  { id: "claude-opus-4", provider: "anthropic", inPerM: 15, outPerM: 75, cacheReadPerM: 1.5, cacheWritePerM: 18.75 },
];

const AGENTS = ["build", "plan", "explore", "general"];
const TOOLS = ["bash", "read", "write", "edit", "glob", "grep", "task", "webfetch", "todowrite"];
const TITLES = [
  "Refactor auth module",
  "Add telemetry dashboard",
  "Fix CI pipeline",
  "Investigate slow queries",
  "Update component library",
  "Write unit tests for API",
  "Migrate to new SDK",
  "Optimize bundle size",
  "Set up monitoring alerts",
  "Review deployment scripts",
];

function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pick(arr) {
  return arr[rand(0, arr.length - 1)];
}

function weightedTool() {
  const r = Math.random();
  if (r < 0.3) return "bash";
  if (r < 0.5) return "read";
  if (r < 0.62) return "edit";
  if (r < 0.72) return "write";
  if (r < 0.8) return "grep";
  if (r < 0.86) return "glob";
  if (r < 0.92) return "task";
  if (r < 0.96) return "webfetch";
  return "todowrite";
}

function createSchema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS session (
      id TEXT PRIMARY KEY,
      project_id TEXT,
      parent_id TEXT,
      slug TEXT,
      directory TEXT,
      title TEXT,
      version TEXT,
      share_url TEXT,
      summary_additions INTEGER,
      summary_deletions INTEGER,
      summary_files INTEGER,
      summary_diffs TEXT,
      revert TEXT,
      permission TEXT,
      time_created INTEGER,
      time_updated INTEGER,
      time_compacting INTEGER,
      time_archived INTEGER,
      workspace_id TEXT,
      path TEXT,
      agent TEXT,
      model TEXT,
      cost REAL,
      tokens_input INTEGER,
      tokens_output INTEGER,
      tokens_reasoning INTEGER,
      tokens_cache_read INTEGER,
      tokens_cache_write INTEGER,
      metadata TEXT
    );
    CREATE TABLE IF NOT EXISTS message (
      id TEXT PRIMARY KEY,
      session_id TEXT,
      time_created INTEGER,
      time_updated INTEGER,
      data TEXT
    );
    CREATE TABLE IF NOT EXISTS part (
      id TEXT PRIMARY KEY,
      message_id TEXT,
      session_id TEXT,
      time_created INTEGER,
      time_updated INTEGER,
      data TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_message_session ON message(session_id);
    CREATE INDEX IF NOT EXISTS idx_part_session ON part(session_id);
  `);
}

function hex(n) {
  const chars = "0123456789abcdef";
  let out = "";
  for (let i = 0; i < n; i++) out += chars[rand(0, 15)];
  return out;
}

export function seed() {
  fs.mkdirSync(path.dirname(config.demoDbPath), { recursive: true });
  if (fs.existsSync(config.demoDbPath)) {
    fs.rmSync(config.demoDbPath);
  }
  const db = new DatabaseSync(config.demoDbPath);
  createSchema(db);

  const now = Date.now();
  const dayMs = 24 * 60 * 60 * 1000;
  const sessionInsert = db.prepare(
    `INSERT INTO session (id, project_id, title, agent, model, cost,
       tokens_input, tokens_output, tokens_reasoning, tokens_cache_read,
       tokens_cache_write, time_created, time_updated, directory)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  const messageInsert = db.prepare(
    "INSERT INTO message (id, session_id, time_created, time_updated, data) VALUES (?, ?, ?, ?, ?)",
  );
  const partInsert = db.prepare(
    "INSERT INTO part (id, message_id, session_id, time_created, time_updated, data) VALUES (?, ?, ?, ?, ?, ?)",
  );

  let totalSessions = 0;
  let totalMessages = 0;
  let totalParts = 0;

  const sessionCount = 22;
  for (let s = 0; s < sessionCount; s++) {
    const model = pick(MODELS);
    const agent = pick(AGENTS);
    const daysAgo = sessionCount - s; // 22..1 -> oldest first
    const created = now - daysAgo * dayMs - rand(0, 8 * 60 * 60 * 1000);
    const sessionId = `ses_demo_${hex(12)}`;
    const title = pick(TITLES);
    const dirs = ["/workspace", "/workspace/src", "/workspace/server", "/workspace/web", "/home/user/proj"];
    const directory = pick(dirs);

    const sessionData = {
      sessionId,
      tokensInput: 0,
      tokensOutput: 0,
      tokensReasoning: 0,
      tokensCacheRead: 0,
      tokensCacheWrite: 0,
      cost: 0,
      lastTs: created,
    };

    // Generate 2-8 user turns per session
    const turns = rand(2, 8);
    for (let t = 0; t < turns; t++) {
      const userTs = sessionData.lastTs + rand(10_000, 180_000);
      const userMsgId = `msg_demo_${hex(12)}`;
      const userData = {
        role: "user",
        time: { created: userTs },
        agent,
        model: { providerID: model.provider, modelID: model.id },
      };
      messageInsert.run(userMsgId, sessionId, userTs, userTs, JSON.stringify(userData));
      totalMessages++;

      // text part for user message
      partInsert.run(
        `prt_demo_${hex(10)}`,
        userMsgId,
        sessionId,
        userTs,
        userTs,
        JSON.stringify({ type: "text", text: `Task request ${t + 1} in ${directory}` }),
      );
      totalParts++;

      // assistant turn with a few tool calls
      const toolSteps = rand(1, 5);
      const asstStart = userTs + rand(1_000, 8_000);
      const tokens = {
        input: rand(400, 6_000),
        output: rand(200, 2_500),
        reasoning: Math.random() < 0.5 ? rand(50, 800) : 0,
        cache: { write: rand(0, 800), read: rand(2_000, 90_000) },
      };
      const cost =
        (tokens.input / 1e6) * model.inPerM +
        (tokens.output / 1e6) * model.outPerM +
        (tokens.cache.read / 1e6) * model.cacheReadPerM +
        (tokens.cache.write / 1e6) * model.cacheWritePerM;

      let asstEnd = asstStart;
      for (let k = 0; k < toolSteps; k++) {
        asstEnd += rand(400, 25_000);
      }
      const asstTs = asstEnd + rand(500, 5_000);
      const asstMsgId = `msg_demo_${hex(12)}`;
      const asstData = {
        parentID: userMsgId,
        role: "assistant",
        mode: "build",
        agent,
        path: { cwd: directory, root: directory },
        cost,
        tokens: { ...tokens, total: tokens.input + tokens.output },
        modelID: model.id,
        providerID: model.provider,
        time: { created: asstStart, completed: asstTs },
        finish: toolSteps > 0 ? "tool-calls" : "end_turn",
      };
      messageInsert.run(asstMsgId, sessionId, asstStart, asstTs, JSON.stringify(asstData));
      totalMessages++;

      sessionData.tokensInput += tokens.input;
      sessionData.tokensOutput += tokens.output;
      sessionData.tokensReasoning += tokens.reasoning || 0;
      sessionData.tokensCacheRead += tokens.cache.read;
      sessionData.tokensCacheWrite += tokens.cache.write;
      sessionData.cost += cost;
      sessionData.lastTs = asstTs;

      // parts: reasoning (optional), text, tool calls
      if (tokens.reasoning) {
        partInsert.run(
          `prt_demo_${hex(10)}`,
          asstMsgId,
          sessionId,
          asstStart,
          asstStart + 500,
          JSON.stringify({
            type: "reasoning",
            text: `Analyzing step ${t + 1} for ${title.toLowerCase()}`,
            time: { start: asstStart, end: asstStart + 500 },
          }),
        );
        totalParts++;
      }
      partInsert.run(
        `prt_demo_${hex(10)}`,
        asstMsgId,
        sessionId,
        asstStart + 100,
        asstStart + 1200,
        JSON.stringify({ type: "text", text: `Working on ${title.toLowerCase()} - step ${t + 1}` }),
      );
      totalParts++;

      let toolTs = asstStart + 1500;
      for (let k = 0; k < toolSteps; k++) {
        const tool = weightedTool();
        const start = toolTs;
        const end = start + rand(300, 20_000);
        const status = Math.random() < 0.08 ? "error" : "completed";
        const inText = { command: `example ${tool} invocation` };
        const outText = status === "completed" ? "ok" : "failed";
        partInsert.run(
          `prt_demo_${hex(10)}`,
          asstMsgId,
          sessionId,
          start,
          end,
          JSON.stringify({
            type: "tool",
            tool,
            callID: `call_demo_${hex(14)}`,
            state: { status, input: inText, output: outText },
            time: { start, end },
          }),
        );
        totalParts++;
        toolTs = end + rand(100, 2_000);
      }
    }

    const finalTs = sessionData.lastTs;
    sessionInsert.run(
      sessionId,
      `proj_demo_${hex(6)}`,
      title,
      agent,
      JSON.stringify({ id: model.id, providerID: model.provider }),
      Number(sessionData.cost.toFixed(4)),
      sessionData.tokensInput,
      sessionData.tokensOutput,
      sessionData.tokensReasoning,
      sessionData.tokensCacheRead,
      sessionData.tokensCacheWrite,
      created,
      finalTs,
      directory,
    );
    totalSessions++;
  }

  db.close();
  return { path: config.demoDbPath, sessions: totalSessions, messages: totalMessages, parts: totalParts };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const result = seed();
  console.log(`Seeded demo database at ${result.path}`);
  console.log(`  sessions: ${result.sessions}, messages: ${result.messages}, parts: ${result.parts}`);
}
