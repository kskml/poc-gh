import { DatabaseSync } from "node:sqlite";
import { existsSync } from "node:fs";

let db = null;

export function openStore(dbPath) {
  if (!existsSync(dbPath)) {
    throw new Error(`Database not found: ${dbPath}`);
  }
  db = new DatabaseSync(dbPath, { readOnly: true });
  db.exec("PRAGMA query_only = ON;");
  return db;
}

export function getDb() {
  if (!db) {
    throw new Error("Store not opened yet");
  }
  return db;
}

export function parseJson(raw, fallback = null) {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

export function rows(stmt, params = []) {
  return stmt.all(...params);
}

export function close() {
  if (db) {
    db.close();
    db = null;
  }
}
