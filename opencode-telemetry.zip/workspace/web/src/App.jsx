import { useState } from "react";
import "./chartSetup.js";
import { useFetch } from "./hooks/useFetch.js";
import {
  fetchStats,
  fetchHealth,
  fetchTimeseries,
  fetchModels,
  fetchAgents,
  fetchTools,
  fetchSessions,
} from "./api.js";
import { formatDate, formatDuration, formatMoney, formatNumber } from "./utils.js";
import KpiCard from "./components/KpiCard.jsx";
import TimeSeriesChart from "./components/TimeSeriesChart.jsx";
import ModelsChart from "./components/ModelsChart.jsx";
import CostPieChart from "./components/CostPieChart.jsx";
import AgentsChart from "./components/AgentsChart.jsx";
import ToolsTable from "./components/ToolsTable.jsx";
import SessionsTable from "./components/SessionsTable.jsx";

const RANGES = [
  { label: "7d", days: 7 },
  { label: "14d", days: 14 },
  { label: "30d", days: 30 },
  { label: "90d", days: 90 },
];

function Card({ title, right, children }) {
  return (
    <div className="card">
      <div className="card-head">
        <h2>{title}</h2>
        {right ? <div className="card-right">{right}</div> : null}
      </div>
      {children}
    </div>
  );
}

export default function App() {
  const [days, setDays] = useState(30);
  const granularity = days <= 2 ? "hour" : "day";

  const stats = useFetch(fetchStats);
  const health = useFetch(fetchHealth);
  const ts = useFetch(() => fetchTimeseries(days, granularity), [days]);
  const models = useFetch(fetchModels);
  const agents = useFetch(fetchAgents);
  const tools = useFetch(fetchTools);
  const sessions = useFetch(() => fetchSessions(30));

  const st = stats.data;
  const lastSeen = st?.lastSeen;
  const span = lastSeen ? formatDuration(Date.now() - new Date(lastSeen).getTime()) : null;
  const sourceIsDemo = health.data?.db?.includes("demo");
  const sourceLabel = sourceIsDemo
    ? "demo dataset"
    : health.data?.db
      ? "live opencode data"
      : "…";

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="logo">o</span>
          <div>
            <h1>opencode telemetry</h1>
            <p className="tagline">session · tokens · cost · tools</p>
          </div>
        </div>
        <div className="topbar-right">
          <span className={`chip ${sourceIsDemo ? "demo" : ""}`}>{sourceLabel}</span>
          {lastSeen ? <span className="chip">last activity {span} ago</span> : null}
          <button className="refresh" onClick={() => stats.reload()} disabled={stats.loading}>
            {stats.loading ? "loading…" : "refresh"}
          </button>
        </div>
      </header>

      {stats.error || ts.error ? (
        <div className="banner error">
          Failed to load data. Is the backend running on port 3001? ({stats.error?.message || ts.error?.message})
        </div>
      ) : null}

      {st ? (
        <section className="kpis">
          <KpiCard label="Sessions" value={formatNumber(st.sessions)} sub={`across ${st.activeDays} active days`} />
          <KpiCard label="Messages" value={formatNumber(st.messages)} sub={`${formatNumber(st.userMessages)} user · ${formatNumber(st.assistantMessages)} assistant`} accent="#22d3ee" />
          <KpiCard label="Total tokens" value={formatNumber(st.totalTokens)} sub={`cache ${formatNumber(st.tokensCacheRead)} read`} accent="#a78bfa" />
          <KpiCard label="Est. cost" value={formatMoney(st.cost)} sub={`${st.models} models · ${st.agents} agents`} accent="#34d399" />
          <KpiCard label="Tool calls" value={formatNumber(st.toolCalls)} sub={`${st.tools} distinct tools`} accent="#fbbf24" />
          <KpiCard label="Text output" value={formatNumber(st.textChars)} sub={`${formatNumber(st.reasoningChars)} reasoning chars`} accent="#f472b6" />
        </section>
      ) : null}

      <Card
        title="Usage over time"
        right={
          <div className="segmented">
            {RANGES.map((r) => (
              <button
                key={r.days}
                className={days === r.days ? "active" : ""}
                onClick={() => setDays(r.days)}
              >
                {r.label}
              </button>
            ))}
          </div>
        }
      >
        {ts.data ? <TimeSeriesChart data={ts.data} granularity={granularity} /> : <div className="loading">loading…</div>}
      </Card>

      <div className="grid-2">
        <Card title="Cost & tokens by model">
          {models.data ? <ModelsChart models={models.data} /> : <div className="loading">loading…</div>}
        </Card>
        <Card title="Cost share by model">
          {models.data ? <CostPieChart models={models.data} /> : <div className="loading">loading…</div>}
        </Card>
      </div>

      <Card title="Messages & tokens by agent">
        {agents.data ? <AgentsChart agents={agents.data} /> : <div className="loading">loading…</div>}
      </Card>

      <div className="grid-2">
        <Card title="Tool usage">
          {tools.data ? <ToolsTable tools={tools.data} /> : <div className="loading">loading…</div>}
        </Card>
        <Card title="Recent sessions">
          {sessions.data ? <SessionsTable sessions={sessions.data} /> : <div className="loading">loading…</div>}
        </Card>
      </div>

      <footer className="footer">
        reads opencode.db · source data window:{" "}
        {st?.firstSeen ? `${formatDate(st.firstSeen, { hour: undefined, minute: undefined })} → ${formatDate(lastSeen, { hour: undefined, minute: undefined })}` : "—"}
      </footer>
    </div>
  );
}
