const BASE = "/api";

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) {
    throw new Error(`${res.status}: ${await res.text()}`);
  }
  return res.json();
}

export const fetchStats = () => get("/stats");
export const fetchHealth = () => get("/health");
export const fetchTimeseries = (days = 30, granularity = "day") =>
  get(`/timeseries?days=${days}&granularity=${granularity}`);
export const fetchModels = () => get("/models");
export const fetchAgents = () => get("/agents");
export const fetchTools = () => get("/tools");
export const fetchSessions = (limit = 50) => get(`/sessions?limit=${limit}`);
export const fetchMessages = (limit = 100) => get(`/messages?limit=${limit}`);
