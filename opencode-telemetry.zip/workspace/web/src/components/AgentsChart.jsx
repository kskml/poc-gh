import { Bar } from "react-chartjs-2";
import { formatNumber, PALETTE } from "../utils.js";

export default function AgentsChart({ agents }) {
  const labels = agents.map((a) => a.agent);
  const messages = agents.map((a) => a.messages);
  const toolTokens = agents.map((a) => a.tokensTotal);

  const data = {
    labels,
    datasets: [
      {
        label: "Messages",
        data: messages,
        backgroundColor: PALETTE[2],
        yAxisID: "y",
      },
      {
        label: "Tokens",
        data: toolTokens,
        backgroundColor: PALETTE[3],
        yAxisID: "y1",
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { labels: { color: "#cbd5e1", boxWidth: 12 } },
      tooltip: {
        callbacks: {
          label: (ctx) => `${ctx.dataset.label}: ${formatNumber(ctx.parsed.y)}`,
        },
      },
    },
    scales: {
      x: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(148,163,184,0.08)" } },
      y: {
        position: "left",
        ticks: { color: "#64748b", callback: (v) => formatNumber(v) },
        grid: { color: "rgba(148,163,184,0.08)" },
        beginAtZero: true,
      },
      y1: {
        position: "right",
        ticks: { color: "#64748b", callback: (v) => formatNumber(v) },
        grid: { drawOnChartArea: false },
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="chart-container">
      <Bar data={data} options={options} />
    </div>
  );
}
