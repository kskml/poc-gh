import { Pie } from "react-chartjs-2";
import { formatMoney, PALETTE } from "../utils.js";

export default function CostPieChart({ models }) {
  const top = models.slice(0, 8);
  const data = {
    labels: top.map((m) => m.model),
    datasets: [
      {
        data: top.map((m) => m.cost),
        backgroundColor: PALETTE,
        borderWidth: 0,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: "right", labels: { color: "#cbd5e1", boxWidth: 12 } },
      tooltip: {
        callbacks: {
          label: (ctx) => {
            const total = top.reduce((s, m) => s + m.cost, 0);
            const pct = total ? ((ctx.parsed / total) * 100).toFixed(1) : 0;
            return `${ctx.label}: ${formatMoney(ctx.parsed)} (${pct}%)`;
          },
        },
      },
    },
  };

  return (
    <div className="chart-container">
      <Pie data={data} options={options} />
    </div>
  );
}
