import { Bar } from "react-chartjs-2";
import { formatMoney, formatNumber, PALETTE } from "../utils.js";

export default function ModelsChart({ models }) {
  const top = models.slice(0, 8);
  const labels = top.map((m) => m.model);
  const costData = top.map((m) => m.cost);
  const tokenData = top.map((m) => m.tokensTotal);

  const data = {
    labels,
    datasets: [
      {
        label: "Cost (USD)",
        data: costData,
        backgroundColor: PALETTE[0],
        yAxisID: "y",
      },
      {
        label: "Tokens total",
        data: tokenData,
        backgroundColor: PALETTE[1],
        yAxisID: "y1",
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { labels: { color: "#cbd5e1", boxWidth: 12 } },
      tooltip: {
        callbacks: {
          label: (ctx) =>
            ctx.dataset.yAxisID === "y"
              ? `Cost: ${formatMoney(ctx.parsed.y)}`
              : `Tokens: ${formatNumber(ctx.parsed.y)}`,
        },
      },
    },
    scales: {
      x: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(148,163,184,0.08)" } },
      y: {
        position: "left",
        ticks: { color: "#64748b", callback: (v) => formatMoney(v) },
        grid: { color: "rgba(148,163,184,0.08)" },
        beginAtZero: true,
      },
      y1: {
        position: "right",
        ticks: { color: "#64748b", callback: (v) => formatNumber(v) },
        grid: { drawOnChartArea: false },
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="chart-container">
      <Bar data={data} options={options} />
    </div>
  );
}
