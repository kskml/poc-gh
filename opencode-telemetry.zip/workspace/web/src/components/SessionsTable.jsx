import { formatDate, formatDuration, formatMoney, formatNumber } from "../utils.js";

export default function SessionsTable({ sessions }) {
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            <th>Session</th>
            <th>Model</th>
            <th>Agent</th>
            <th>Messages</th>
            <th>Tool calls</th>
            <th>Tokens</th>
            <th>Cost</th>
            <th>Duration</th>
            <th>Last activity</th>
          </tr>
        </thead>
        <tbody>
          {sessions.map((s) => (
            <tr key={s.id}>
              <td className="title-cell" title={s.id}>{s.title}</td>
              <td>
                <span className="badge">{s.model}</span>
              </td>
              <td>{s.agent}</td>
              <td>{s.messages}</td>
              <td>{s.toolCalls}</td>
              <td>{formatNumber(s.tokensInput + s.tokensOutput)}</td>
              <td>{formatMoney(s.cost)}</td>
              <td>{formatDuration(s.durationMs)}</td>
              <td className="dim">{formatDate(s.timeUpdated, { hour: undefined, minute: undefined })}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
