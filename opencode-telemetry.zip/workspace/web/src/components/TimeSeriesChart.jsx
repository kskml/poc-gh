import { Line } from "react-chartjs-2";
import { formatNumber } from "../utils.js";

export default function TimeSeriesChart({ data, granularity }) {
  const labels = data.map((d) =>
    granularity === "hour"
      ? new Date(d.ts).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit" })
      : new Date(d.ts).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
  );

  const chartData = {
    labels,
    datasets: [
      {
        label: "Cache read",
        data: data.map((d) => d.tokensCacheRead),
        borderColor: "#22d3ee",
        backgroundColor: "rgba(34,211,238,0.1)",
        fill: true,
        tension: 0.35,
      },
      {
        label: "Input",
        data: data.map((d) => d.tokensInput),
        borderColor: "#6366f1",
        backgroundColor: "rgba(99,102,241,0.08)",
        fill: true,
        tension: 0.35,
      },
      {
        label: "Output",
        data: data.map((d) => d.tokensOutput),
        borderColor: "#34d399",
        backgroundColor: "rgba(52,211,153,0.08)",
        fill: true,
        tension: 0.35,
      },
      {
        label: "Reasoning",
        data: data.map((d) => d.tokensReasoning),
        borderColor: "#fbbf24",
        backgroundColor: "rgba(251,191,36,0.08)",
        fill: true,
        tension: 0.35,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: "index", intersect: false },
    plugins: {
      legend: { labels: { color: "#cbd5e1", boxWidth: 12 } },
      tooltip: {
        callbacks: {
          label: (ctx) => `${ctx.dataset.label}: ${formatNumber(ctx.parsed.y)}`,
        },
      },
    },
    scales: {
      x: { ticks: { color: "#64748b", maxTicksLimit: 12 }, grid: { color: "rgba(148,163,184,0.08)" } },
      y: {
        ticks: { color: "#64748b", callback: (v) => formatNumber(v) },
        grid: { color: "rgba(148,163,184,0.08)" },
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="chart-container">
      <Line data={chartData} options={options} />
    </div>
  );
}
