export default function ToolsTable({ tools }) {
  const maxCalls = Math.max(1, ...tools.map((t) => t.calls));
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            <th>Tool</th>
            <th>Calls</th>
            <th>Success</th>
            <th>Failed</th>
            <th>Success rate</th>
            <th>Avg duration</th>
          </tr>
        </thead>
        <tbody>
          {tools.map((t) => (
            <tr key={t.tool}>
              <td>
                <div className="bar-cell">
                  <span className="tool-name">{t.tool}</span>
                  <div className="mini-bar">
                    <div
                      className="mini-bar-fill"
                      style={{ width: `${(t.calls / maxCalls) * 100}%` }}
                    />
                  </div>
                </div>
              </td>
              <td>{t.calls}</td>
              <td className="ok">{t.success}</td>
              <td className={t.failed > 0 ? "err" : ""}>{t.failed}</td>
              <td>
                <span className={`rate ${t.successRate >= 95 ? "ok" : t.successRate >= 80 ? "warn" : "err"}`}>
                  {t.successRate}%
                </span>
              </td>
              <td>{t.avgMs >= 1000 ? `${(t.avgMs / 1000).toFixed(1)}s` : `${t.avgMs}ms`}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
