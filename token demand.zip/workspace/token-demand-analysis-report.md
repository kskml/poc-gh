# AI Token Demand Analysis Report — GitHub Copilot

**A data-driven estimation model for GitHub Copilot agentic coding workloads — Claude Sonnet 4 baseline**

*Prepared: 2026-07-31 · Version 3.2 (token-only edition — supersedes v3.1 and `token-demand-estimation-framework.md`)*

> Calculator: `docs/token-demand-estimator.py` · Calibration form: `docs/token-usage-data-form.html`.
> This report estimates **token demand only**. Pricing is intentionally out of scope.

---

## 1. Executive summary

This report presents a calibration-ready model to estimate **how many tokens GitHub Copilot
consumes on a Jira story**, driven by story complexity, user role (developer / architect),
task criteria, and installed optimization techniques.

**Token estimates are the durable output of the model.** They are a property of the work
itself — how much Copilot reads and writes — and are unaffected by model pricing.

Key findings:

| Finding | Value |
|---|---|
| Input tokens dominate | ~90% of all tokens are input (what Copilot reads) |
| Developer, M-story (3–5 SP) | **~500k tokens** (450k input / 50k output) |
| Architect, L-story (8 SP) | **~3.6M tokens** |
| Architect vs developer at same complexity | **1.4×** (heavy reading profile) |
| Tokens per complexity level (developer) | 12k (XXS) → **5.55M (XL)** |
| Optimization "reward points" | modest: a well-tuned stack (AGENTS.md, skills, hooks, MCP, memory) yields **~25%**, a full stack ~40% |
| Biggest single lever | **modality**: chat 0.3× vs agent 1.0× vs MCP-heavy 1.5× |
| Baseline model | Claude Sonnet 4 via GitHub Copilot |

**Bottom line for budgeting:** one developer running a typical month (10 S + 20 M + 5 L +
1 XL stories, medium repo, agent mode) consumes **~24M tokens** (§10). A 5-developer team at
that load ≈ **~120M tokens**. Optimize the *input* side first (compression hooks, symbol
retrieval, memory), because that is where ~90% of tokens live.

---

## 2. Scope, terminology, and baseline

### 2.1 Terminology

| Term | Definition |
|---|---|
| **Token** | smallest unit of text the model processes; ~4 chars ≈ 1 token (Claude byte-pair encoding) |
| **Input tokens** | every token Copilot *reads*: system prompt, instructions, retrieved files, tool output, conversation history |
| **Output tokens** | every token Copilot *writes*: replies, code edits, design docs |
| **Turn** | one model call (prompt → response); a session is many turns |
| **Session** | a continuous agent conversation (e.g. one VS Code Copilot chat / Copilot CLI session) |
| **Agentic task** | work performed with tool execution (read/grep/bash/edit) rather than chat-only |

### 2.2 Baseline model

Token budgets throughout this report are calibrated to **Claude Sonnet 4 via GitHub
Copilot** (Copilot's mid-tier "Versatile" model). This is the **baseline model**: the token
counts are measured for this model, and the same budgets apply regardless of which Copilot
model you actually run. **Model choice and pricing are out of scope here** — they affect
what you pay per token, not how many tokens are read and written.

### 2.3 Scope and assumptions

- Workload: **agentic coding** (tool-using agents) in GitHub Copilot — agent mode, Copilot
  CLI, cloud agent.
- Unit of analysis: **one Jira user story**, sized by story points.
- Roles considered: **developer and architect** (the two calibration roles). Other roles
  are out of scope.
- Default scenario: medium repo, agent mode, no optimization, developer role.
- Estimates are **ranges** (P10 / P50 / P90). Single-point forecasts are an anti-pattern.

---

## 3. Core principle

### 3.1 Token demand = read × write × round-trips

Token consumption is the product of three independent quantities:

```
Token demand = (reading volume) × (writing volume) × (round-trips)
```

- **Reading volume** (input): how much context Copilot pulls in per turn.
- **Writing volume** (output): how much it generates per turn.
- **Round-trips** (turns): how many prompt→response cycles the task needs.

A task can be expensive for very different reasons: a huge unfamiliar monorepo is
expensive because of *reading volume*; a sprawling ambiguous story is expensive because
of *round-trips* (rework). Optimization must target the dominant driver.

### 3.2 The 90/10 input rule

Across measured agentic sessions, **~90% of tokens are input**. In a typical M-story
(450k input / 50k output), Copilot reads nine tokens for every token it writes. The
**token** fight, and therefore the highest-leverage savings, is on the input side.

### 3.3 Master formula

```
Input_tokens   = Base_input(complexity) × R × C × M × H × O
Output_tokens  = Base_output(complexity) × R × M × H × O
```

```mermaid
graph TD
    A["Jira story points"] --> B["Complexity level (XXS-XL)"]
    B --> C["Base input and output tokens (P10-P90)"]
    C --> D["Role factor R: developer 1.0 / architect 1.4"]
    D --> E["Context C, Modality M, Rework H"]
    E --> F["Optimization reward points -> factor O"]
    F --> G["Estimated input and output tokens"]
```

---

## 4. Data sources — real token telemetry

The model is calibrated against **measured** token data collected from production tools,
benchmarks, and published telemetry (not guessed values).

| # | Source (tool / study) | Measurement | Measured value | Signal for the model |
|---|---|---|---|---|
| 1 | Claude Code enterprise usage (Anthropic, 2025–26) | avg. tokens per active developer-day | ~4M tokens/day | daily session volume |
| 2 | claude-code-memory-setup (lucasrosati, 2026) | repo-orientation tokens, 40-file project | ~20k/session | cold-start explore cost |
| 3 | caveman benchmark corpus (10 prompts, Claude API, 2026) | output tokens per reply | 1,214 → 294 (avg **65%** cut) | output-side compression ceiling |
| 4 | caveman-compress receipts | memory/instructions file tokens | 898 → 481 (avg **46%**) | static context can be halved |
| 5 | jCodeMunch live telemetry (2026) | tokens saved on code exploration | **583B+** saved; **99.6%** avg reduction | exploration is the dominant input sink |
| 6 | context-mode (mksglu, 2026) | sandboxed tool output | 315 KB → 5.4 KB (**98%**) | tool-output vs context ratio |
| 7 | pxpipe (teamchong, 2026) | dense text vs image tokens | ~48k chars ≈ 25k tokens → 2.7k | token density leverage |
| 8 | rtk (rtk-ai, 2026) | bash-output reduction | up to **90%** (100+ commands) | verify-phase input reduction |
| 9 | LLMLingua (Microsoft, 2023–24) | prompt compression | up to **20×** | theoretical input floor |

**How the measurements calibrate the model:** the base budgets in §5 are set so that a
single M-story ≈ 450k input tokens ≈ ~10% of a heavy developer-day (consistent with #1),
of which exploration ≈ 150k (consistent with #2–#6), and the output budget ≈ 50k
(consistent with #3 at session scale). Rows #5, #6, #8 justify the optimization reward
points in §9: they tell us *which* input classes shrink the most.

---

## 5. Jira story complexity

Story points are the primary driver. Map points to a complexity level and a **base token
budget** (calibrated from §4). The ranges are the P10–P90 band; P50 is the central value.

| Level | Story points | Files touched | Turns | Base input (k) | Base output (k) | Total (k) | Typical example |
|---|---|---|---|---|---|---|---|
| **XXS** | 0.5 | 1 | **1–3** | **5–15** | **1–3** | **6–18** | typo, config toggle, one-line fix |
| **S** | 1–2 | 1–2 | **6–12** | **60–140** | **6–16** | **66–156** | single-file bug fix |
| **M** | 3–5 | 2–4 | 25–50 | 300–600 | 30–70 | 330–670 | feature in 1–2 files |
| **L** | 8 | 4–8 | 60–120 | 900–1,800 | 90–200 | 1,000–2,000 | new module / integration |
| **XL** | 13+ | 8+ / several services | 150–400 | 3,000–7,000 | 300–800 | 3,300–7,800 | epic, cross-service |

**How to read the table:** *Turns* is one prompt→response round-trip. A 0.5-point typo fix
really is 1–3 turns — the agent reads the file, edits it, maybe runs one check. An XL epic
spans 150–400 turns because it is dozens of separate sessions stitched together. *Base
input* is the tokens the model *reads* (system prompt + retrieved files + tool output +
history); *base output* is what it writes. The ranges are P10–P90; P50 is the midpoint.

**Quick in-session check (one glance, no math):**
`total ≈ input × 1.1` because output is ~10% of input.
Example: you hover a session and see **450k input** → expect **~500k total** (450k + ~50k
output). If the session shows 1.1M total, input is ~1M. If your actual ratio is far from
this (say 1.5×), you are either pasting huge files, or your agent is echoing context —
that ratio is itself a health signal.

### Tokens by complexity (developer vs architect, medium repo, agent mode)

| Level | SP | Input (k) | Output (k) | Total (k) | **Developer total (k)** | Architect total (k) |
|---|:--:|--:|--:|--:|--:|--:|
| XXS | 0.5 | 10 | 2 | 12 | **12** | 17 |
| S | 1–2 | 100 | 11 | 111 | **111** | 155 |
| M | 3–5 | 450 | 50 | 500 | **500** | 700 |
| L | 8 | 1,350 | 145 | 1,495 | **1,495** | 2,093 |
| XL | 13+ | 5,000 | 550 | 5,550 | **5,550** | 7,770 |

```mermaid
xychart-beta
    title "Estimated tokens by story complexity (central, Sonnet)"
    x-axis ["XXS","S","M","L","XL"]
    y-axis "Tokens (k)" 0 --> 8000
    bar [12,111,500,1495,5550]
    bar [17,155,700,2093,7770]
    legend ["Developer","Architect"]
```

**Reading the table:** the Developer column is the baseline scenario; the Architect column
is the same story at 1.4×. A **0.5-point story ≈ 12k tokens** — so a single typo fix is
the cheapest unit of agentic work, while an **XL epic (13+ SP) ≈ 5.55M tokens**. This is
why the level classification dominates your budget: getting "M vs L" wrong changes the
estimate by 3×.

Token consumption is **super-linear in story points**: an XL epic consumes ~11× the
tokens of an M story, so complexity misclassification is the single biggest estimation
error source. Size conservatively.

---

## 6. Token anatomy within a user story

A story is not one prompt; it is a sequence of phases, each with a different token
profile. Decomposition for a **developer, M-story** (P50: 450k input / 50k output):

| Phase | What Copilot does | Input (k) | Output (k) | Share of input |
|---|---|---|---|---|
| Plan | read story, clarify, outline steps | 40 | 3 | 9% |
| Explore | grep / search / read files / repo map | **150** | 2 | **33%** |
| Implement | write / edit code | 120 | **30** | 27% |
| Verify | run tests, read failures, fix | 80 | 8 | 18% |
| Review | self-review, refactor, edge cases | 40 | 5 | 9% |
| Communicate | commit msg, summary, PR description | 20 | 2 | 4% |
| **Total** | | **450** | **50** | 100% |

```mermaid
pie showData
    title "Input token anatomy - M story (450k)"
    "Explore" : 150
    "Implement" : 120
    "Verify" : 80
    "Plan" : 40
    "Review" : 40
    "Communicate" : 20
```

### Interpretation

1. **Explore is the largest input sink (33%).** This is where symbol-level retrieval
   (jCodeMunch-class) and repo maps pay off: telemetry #5 shows code-exploration tokens
   shrink ~99% with symbol-level queries.
2. **Verify is 18% of input** and the most compressible — test-run output is ~90%
   compressible (#6, #8), so the 80k in this phase can drop to ~15–20k.
3. **Implement is output-heavy (60% of output)** — the style-skill family (#3) cuts the
   30k output here by up to 65%, but only the *prose* portion.
4. **Plan + Communicate are mostly fixed overhead** — driven by system prompt + story
   text; they shrink only via concise instructions.

---

## 7. The estimation model (full specification)

### 7.1 Factor reference

| Factor | Meaning | Values |
|---|---|---|
| **R — role** | work profile multiplier | **developer 1.0 · architect 1.4** |
| **C — codebase** | repo size / familiarity (input only) | small 0.8 · medium 1.0 · large 1.5 · huge/unfamiliar 2.0 |
| **M — modality** | how the agent operates | chat 0.3 · editor 0.6 · agent 1.0 · agent+subagents 1.2 · agent+MCP-heavy 1.5 |
| **H — rework** | ambiguity / iterations | 1.0 base; +0.2 if >6 AC; +0.2 novel domain; +0.3 flaky tests/deps; cap 1.5 |
| **O — optimization** | from reward points (§9) | 1.0 → 0.50 as points 0 → 46; `O = 1 − 0.01 × points` |

### 7.2 Why multiplicative?

Each factor is an independent elasticity: doubling rework doubles every phase's tokens;
going from agent to agent+subagents raises both read and write volume. Multiplicative
composition preserves this, is transparent, and is trivial to audit. It is a
**log-linear model**: `ln(tokens) = ln(base) + Σ ln(factor)`, which is exactly how the
calibration regression in §13 is fitted.

### 7.3 Worked derivation (annotated)

Scenario: **Architect, L-story (8 SP), large repo, agent+subagents, no optimization.**

```
Step 1  Base (Table §5, P50)          input 1,350k   output 145k
Step 2  R = 1.4 (architect)           input 1,890k   output 203k
Step 3  C = 1.5 (large repo, input)   input 2,835k   output 203k
Step 4  M = 1.2 (agent+subagents)     input 3,402k   output 244k
Step 5  H = 1.0, O = 1.0              input 3,402k   output 244k
```

Every number above is traceable to one factor in one table — the property that makes the
model auditable and teachable.

---

## 8. Role analysis — Developer vs Architect

The two focus roles have structurally different token profiles.

### 8.1 Profiles

| Dimension | Developer | Architect |
|---|---|---|
| Core activity | implement + test | design + cross-service analysis |
| Read profile | 2–4 files deep per task | broad: ADRs, schemas, N services |
| Write profile | code edits, test fixes | design docs, ADRs, review comments |
| Dominant phase | Implement + Verify | Explore + Plan + Communicate |
| Typical modality | agent | agent + subagents |
| Factor R | 1.0 | 1.4 |
| Why more tokens | — | reads 1.4×; writes *different* (docs) rather than less |

### 8.2 Phase-level comparison (M-story, P50, before C/M/H)

| Phase | Dev input (k) | Dev output (k) | Arch input (k) | Arch output (k) |
|---|---|---|---|--:|
| Plan | 40 | 3 | 56 | 4 |
| Explore | 150 | 2 | 210 | 3 |
| Implement | 120 | 30 | 168 | 21 *(docs/design, less code)* |
| Verify | 80 | 8 | 112 | 11 |
| Review | 40 | 5 | 56 | 20 *(design review)* |
| Communicate | 20 | 2 | 28 | 11 *(ADR, decision log)* |
| **Total** | **450** | **50** | **630** | **70** |

The architect's *output* shifts from code to documentation but does not shrink — it moves
later in the session (Review/Communicate).

### 8.3 Token comparison (developer vs architect)

| Complexity | Developer (k) | Architect (k) | Ratio |
|---|--:|--:|:--:|
| XXS | 12 | 17 | 1.4× |
| S | 111 | 155 | 1.4× |
| M | 500 | 700 | 1.4× |
| L | 1,495 | 2,093 | 1.4× |
| XL | 5,550 | 7,770 | 1.4× |

### 8.4 Interpretation

- At identical complexity, an architect consumes **1.4×** — purely the R factor.
- In practice the gap is wider: architects usually take *larger* stories (L/XL) and work
  on *larger* repos (C = 1.5). **Developer × S-story ≈ 111k tokens** vs **Architect ×
  L-story ≈ 3.6M tokens** — a ~33× spread driven by complexity (level), role (R), and
  repo (C), in that order of importance.
- Budget implication: assign architects to L+ stories deliberately; their per-story token
  consumption is 10–20× a developer's average, but the *quantity* of stories is far
  smaller.

---

## 9. Optimization reward points

Optimization techniques act as **reward points** — each contributes a modest reduction to
a specific token class. Individually minor; stacked, meaningful (~25–40%). They never
outweigh complexity and role.

### 9.1 Points ledger

| # | Technique | Token class reduced | Typical reduction | Points |
|---|---|---|---|---|
| 1 | Concise `AGENTS.md` / `copilot-instructions.md` | instructions (every turn) | 5–10% | 2 |
| 2 | Ignore files (`.gitignore`, `files.exclude`) | exploration | 5–15% | 3 |
| 3 | Repo map / `#codebase` semantic index | exploration | 20–40% | 5 |
| 4 | Skills / prompt files (on-demand context) | instructions | 5–15% | 3 |
| 5 | Output-compression hooks (rtk / squeez / snip) | tool output (verify) | 40–90% | 8 |
| 6 | Symbol-level retrieval MCP (jCodeMunch) | code reads (explore) | 60–95% | 10 |
| 7 | Cross-session memory (claude-mem) | re-orientation (plan/explore) | 30–70% | 4 |
| 8 | Style skill (caveman / honey) | output tokens | 30–65% | 4 |
| 9 | Compaction discipline (`/compact`, context editing) | history (later turns) | 20–50% | 4 |
| | **Maximum** | | | **43** |

### 9.2 Converting points to the O factor

```
O = 1 − 0.01 × points        (floor 0.50)
```

| Configuration | Points | O | Effective reduction |
|---|---|---|---|
| None | 0 | 1.00 | 0% |
| Basic (AGENTS.md + ignore files) | 5 | 0.95 | 5% |
| Standard (… + skills + compaction) | 13 | 0.87 | 13% |
| Good (… + hooks + style skill) | 25 | 0.75 | 25% |
| Full stack (… + symbol MCP + memory) | 40 | 0.60 | 40% |

**Honest framing:** even the *full* stack removes 40% of tokens, while changing complexity
from M to L multiplies tokens ~3×. Optimization points are the **final adjustment**,
applied *after* complexity and role are fixed — that is why their impact on the estimate
is minor compared with the primary drivers, exactly as observed in practice.

### 9.3 Worked example

Developer, M-story, medium repo, agent mode, with AGENTS.md + ignore + `#codebase` +
skills + output hooks + style skill (**25 points → O = 0.75**):

```
Base 450k/50k → input 337.5k, output 37.5k   (375k total tokens, −25%)
```

---

## 10. Monthly token demand (how to roll up a month)

**Method — bottom-up by story count.** Estimate each story with the model (§7), then sum:

```
Monthly_tokens = Σ per level  ( P50_story_tokens  × stories_that_month )
```

**Worked example** (developer, medium repo, agent mode, no optimization — runnable as
`python3 token-demand-estimator.py --monthly "S=10,M=20,L=5,XL=1"`):

| Level | Stories | Tokens/story (k) | Line tokens (M) |
|---|--:|--:|--:|
| S | 10 | 111 | 1.1 |
| M | 20 | 500 | 10.0 |
| L | 5 | 1,495 | 7.5 |
| XL | 1 | 5,550 | 5.6 |
| **Month total** | **36** | | **24.1** |

For a 5-developer team at the same mix, multiply by 5 → **~120M tokens/month**.

**Shortcut — top-down by active days:** a heavy Copilot developer-day ≈ **4M tokens**
(data source #1, §4). So `monthly_tokens ≈ active_days × 4M × number_of_users`.
Cross-check the bottom-up figure against this; if they disagree by more than ~2×, your
story mix or factor assumptions are off.

> The estimator's `--monthly` flag computes this table directly. The form
> (`token-usage-data-form.html`) has a monthly token projection panel that does the same
> live.

---

## 11. Worked scenarios

### Scenario A — Developer, S-story bug fix (2 SP), medium repo, agent mode

```
R=1.0  C=1.0  M=1.0  H=1.0  O=1.0
Input 100k · Output 11k
Total ≈ 111k tokens     (P10 66k – P90 156k)
```

### Scenario B — Architect, L-story new service (8 SP), large repo, agent+subagents

```
R=1.4  C=1.5  M=1.2  H=1.0  O=1.0
Input 1,350k × 2.52 = 3,402k · Output 145k × 1.68 = 244k
Total ≈ 3.6M tokens     (P10 2.4M – P90 4.9M)
```

### Scenario C — Developer, M-story (3–5 SP), ambiguous (+0.3 H), **good optimization** (25 pts, O=0.75)

```
R=1.0  C=1.0  M=1.0  H=1.3  O=0.75
Input 450k × 1.3 × 0.75 = 439k · Output 50k × 1.3 × 0.75 = 49k
Total ≈ 488k tokens     (vs plain M-story 500k)
```

Scenario C shows the realistic combined effect: rework (+30%) nearly cancels the
optimization (−25%) in raw tokens. Optimizing *then* measuring beats assuming.

---

## 12. Sensitivity analysis

Sensitivity of a **developer M-story** (500k tokens central) to each factor, one factor
moved at a time:

| Factor | Low value | High value | Tokens low | Tokens high | Swing |
|---|---|---|---|---|---|---|:---:|
| Role R | 1.0 (developer) | 1.4 (architect) | 500k | 700k | 1.4× |
| Context C | 0.8 (small) | 2.0 (huge) | 410k | 950k | 2.3× |
| Modality M | 0.3 (chat) | 1.5 (MCP-heavy) | 150k | 750k | 5.0× |
| Rework H | 1.0 | 1.5 | 500k | 750k | 1.5× |
| Optimization O | 1.0 (none) | 0.60 (full) | 500k | 300k | 1.7× |

**Reading:** modality is by far the biggest swinger (5× — the same code change costs ~5×
more tokens in MCP-heavy agent mode than chat). Role, context, and optimization each move
tokens by ~1.4–2.3×. Any estimate is dominated by (a) whether the story is really the
level you think, and (b) how the agent actually runs.

---

## 13. Validation and calibration

### 13.1 Model vs measured data (plausibility checks)

| Check | Measured / external | Model (this report) | Verdict |
|---|---|---|---|
| Heavy developer-day volume | ~4M tokens (§4 #1) | 8–9 M-stories ≈ 4M tokens | consistent |
| Repo orientation cost | ~20k tokens for 40-file repo (#2) | Explore phase (S) ≈ 20–50k | consistent (multiple sessions) |
| Output per reply | 1,214 avg tokens (#3) | Implement phase ≈ 30k over ~40 turns ≈ 750/turn | consistent |
| Code-read compression | 99.6% (#5) | Explore drops 150k → ~10k with symbol MCP | consistent |
| Tool-output compression | up to 90% (#6, #8) | Verify drops 80k → ~15k with hooks | consistent |

The model's central values fall inside the measured bands on every check. Residual
variance is absorbed by the P10–P90 range, which is why the range is the product, not the
point.

### 13.2 Calibration loop

The base table (§5) and role factors (§8) are **starting priors**, re-fit from your own
telemetry every 5–10 stories. The loop has five steps:

1. **Log per story:** `points | role | mode | repo | points-scored | actual_in | actual_out`.
2. **Source actuals in Copilot:** the session context-window control for session token
   totals. rtk `rtk gain --all --format json` and snip `/snip-gain` complement Copilot's
   numbers. Use the calibration form (`docs/token-usage-data-form.html`) — it logs this
   row live and exports CSV.
3. **Recompute `Base_input(level) = P50(actual input)` per level.**
4. **Re-derive `R(role) = P50(role input) / P50(developer input)`.**
5. **Re-fit** is a log-linear regression on `ln(actual) = a + Σ b·ln(factor)`; the P10–P90
   band tightens each cycle.

**Worked mini-example of steps 3–4** (say you log 6 S-stories):

| Story | Points | Role | Actual input (k) | Actual output (k) |
|---|:--:|:--:|--:|--:|
| JIRA-101 | 1 | developer | 95 | 10 |
| JIRA-102 | 2 | developer | 130 | 15 |
| JIRA-103 | 1 | developer | 88 | 9 |
| JIRA-104 | 2 | developer | 142 | 17 |
| JIRA-105 | 8 | architect | 1,900 | 210 |
| JIRA-106 | 8 | architect | 2,100 | 230 |

- `Base_input(S)` re-fit = median(95, 130, 88, 142) = **113k** (default was 100k) → update §5.
- `Base_input(L)` re-fit = median(1,900, 2,100) = **2,000k** (default 1,350k) → your L-stories
  are bigger than the prior; investigate whether they were mis-sized or the repo context
  was large (C=1.5) — if so, log C explicitly next cycle.
- `R(architect)` re-derive = P50(arch input at L) / P50(dev input at L). With only two
  architect samples the ratio is noisy (≈1.5); with 10+ stories the stable ratio will
  converge on the true value. This is exactly why the instruction says **5–10 stories
  minimum** per cell before trusting a re-fit.

> Always fit on **tokens**. Tokens are the durable measure; they carry no pricing baggage.

---

## 14. Limitations and assumptions

1. **±50% band, always.** The P10–P90 range is a feature; a single-point "estimate" is a
   number, not an estimate. *Example:* the S-story central is 111k total, but P90 is 156k —
   a 40% overshoot is within normal variance, not a model bug. Size capacity against P50,
   but budget against P90.
2. **Lumpy sessions.** One giant file read or a verbose `pytest -v` can exceed a whole
   phase. *Example:* reading one 5,000-line generated file is ~200k tokens — a single
   `@` mention of that file can cost more than the entire Verify phase. Optimization
   factors exist to cap these spikes.
3. **Modality is behavioral.** Actual agent usage (chat vs agent vs MCP-heavy) varies
   widely and is the biggest swing factor; measure your real mix, don't assume.
4. **Architect output ≠ smaller.** Docs cost the same per token as code; the 1.4× factor
   reflects higher *reading* plus doc writing, not brevity.
5. **Brevity can trade correctness.** Aggressive style skills can degrade reasoning
   (context-mode kimi-k2.5 note); fold regression-fix loops into H. *Example:* a caveman
   style skill cutting output 65% may save 65% of output tokens but cause a 3-turn
   bug-fix loop that costs more — net loss.
6. **Telemetry mix.** Some §4 sources are vendor benchmarks (caveman, jCodeMunch,
   context-mode); they are used as *ratios* (compression ceilings), not absolute
   workloads, which is why the model stays realistic. *Example:* "99.6% code-read
   compression" from jCodeMunch is an upper bound for the Explore phase, not what every
   session achieves.
7. **Two roles only.** Developer and architect are the calibration roles; other roles
   (QA, PM, reviewer) were deliberately dropped to keep the data-collection loop clean.
   *Implication:* if you must estimate a PM-heavy workload, apply the developer factors
   and accept a wider band rather than inventing a new role factor.
8. **Baseline-dependent.** Token budgets are calibrated to Claude Sonnet 4 via GitHub
   Copilot. Token demand is broadly similar on other models, but this report makes no
   claim about pricing or billing.

---

## 15. References and tooling

- Telemetry sources: rtk (`rtk-ai/rtk`), snip (`snip-ai/snip`), caveman (`JuliusBrussee/caveman`),
  jCodeMunch (`jgravelle/jcodemunch-mcp`), context-mode (`mksglu/context-mode`),
  pxpipe (`teamchong/pxpipe`), claude-mem (`thedotmack/claude-mem`), memory-setup
  (`lucasrosati/claude-code-memory-setup`), LLMLingua (Microsoft).
- Calculator: **`docs/token-demand-estimator.py`** implements this model (developer /
  architect roles, `--points` for optimization reward points,
  `--monthly "S=10,M=20,L=5,XL=1"` for a monthly token projection).
- Calibration form: **`docs/token-usage-data-form.html`** — self-contained, token-first,
  live estimation for developers and architects, with a monthly token projection panel.
