# AI Token Demand Estimation Framework — GitHub Copilot

> **SUPERSEDED by `docs/token-demand-analysis-report.md`** (v3.2, token-only — Claude Sonnet 4
> baseline, real telemetry, reward-points system, developer/architect roles). This document
> remains as the readable "concept first" version; the report is the primary deliverable.
> This framework estimates **token demand only** — pricing is out of scope.

> A practical, calibration-ready framework to estimate how many tokens **GitHub Copilot**
> consumes on a Jira story, driven by **Jira story complexity**, **user role** (developer /
> architect), and other task criteria.
> Companion calculator: `docs/token-demand-estimator.py`.
> Related context: `docs/token-optimization-guide-github-copilot.md` (token levers),
> `docs/token-optimization-tools-effectiveness-copilot.md` (optimization stack).

## 1. Goal and mental model

Estimate *before the work happens* how many tokens GitHub Copilot will consume on a task —
so you can budget sprints and prove the ROI of token-optimization tools. **Token estimates
are the durable output.**

**Core principle:** token demand is a product of **how much the agent reads** (input)
and **how much it writes** (output), multiplied by **how many round-trips** it takes.
Everything else is a multiplier on one of those three numbers.

```
Total tokens ≈ turns × (avg input per turn + avg output per turn)
```

## 2. Token anatomy — where the tokens actually go

For an agentic task (e.g. an M-story, 3–5 story points), a typical Copilot session
decomposes into phases. This is the ground truth the estimation model is fitted to:

| Phase | What happens | Input (k) | Output (k) | Comment |
|---|---|---|---|---|
| Plan | read story, clarify, outline steps | 40 | 3 | system prompt + instructions dominate |
| Explore | grep / search / read files / repo map | 150 | 2 | **the biggest input sink** |
| Implement | write / edit code | 120 | 30 | output-heaviest phase |
| Verify | run tests, read failures, fix loops | 80 | 8 | bash output; shrinks with rtk/squeez |
| Review | self-review, refactor, edge cases | 40 | 5 | |
| Communicate | commit message, summary, PR description | 20 | 2 | |
| **Total** | | **450** | **50** | ≈ 500k tokens for an M story |

Two consequences that drive the whole framework:

1. **Input is ~90% of tokens.** Saving input (compressed tool output, symbol-level
   retrieval, memory) matters far more than saving output.
2. **Turns multiply everything.** A story that takes 100 turns costs ~4× one that takes 25.

## 3. The estimation model

```
Input_tokens   = Base_input(complexity) × R × C × M × H × O
Output_tokens  = Base_output(complexity) × R × M × H × O
```

Where:
- **Base_input / Base_output** — from Jira story complexity (Section 4).
- **R — role factor** (Section 5): developer 1.0 or architect 1.4.
- **C — codebase/context factor** (input only).
- **M — modality factor** (chat vs agent vs subagents).
- **H — rework/ambiguity factor**.
- **O — optimization factor** (from reward points; floor 0.50).

Estimate three numbers: **low** (all inputs at the bottom of their range), **central**
(midpoints), **high** (tops). Report the range, never a single point.

## 4. Criterion 1 — Jira story complexity

Map story points to a complexity level and a base token budget. These are fitted defaults;
calibrate them from your own telemetry (Section 9).

| Level | Story points | Files | Turns | Base input (k) | Base output (k) | Example |
|---|---|---|---|---|---|---|
| **XXS** | 0.5 | 1 | **1–3** | **5–15** | **1–3** | typo, config toggle, one-line fix |
| **S** | 1–2 | 1–2 | **6–12** | **60–140** | **6–16** | single-file bug fix |
| **M** | 3–5 | 2–4 | 25–50 | 300–600 | 30–70 | feature in 1–2 files, edge cases |
| **L** | 8 | 4–8 | 60–120 | 900–1800 | 90–200 | new module, multi-file integration |
| **XL** | 13+ | 8+ / several services | 150–400 | 3000–7000 | 300–800 | epic, cross-service architecture |

**How to read the table.** *Turns* = prompt→response round-trips. Tiny tasks really are
1–3 turns (read file → edit → maybe one test run); an epic is 150–400 turns because it
spans many sessions. *Base input* = what the model reads (system prompt + files + tool
output + history); *base output* = what it writes. The ranges are P10–P90; the central
estimate is the midpoint.

**Quick in-session check (no math needed).** Because output ≈ 10% of input:

```
total_tokens ≈ input_tokens × 1.1        and      input ≈ 90% of total
```

Example: the session window shows **450k input** → expect ~500k total. If a session shows
a ratio far from 1.1× (say 1.6×), the model is re-reading large context repeatedly — a
signal to compact better, not an estimation error.

## 5. Criterion 2 — user role (developer / architect)

Only two roles are in scope for calibration. Roles change the *profile* (read-heavy vs
write-heavy) and the *volume*. The role factor multiplies both input and output.

| Role | R | Profile | Why |
|---|:---:|---|---|
| **Developer** | 1.0 | implement + test | baseline |
| **Architect** | 1.4 | design + heavy reading | reads ADRs, diagrams, cross-service context 2–3×; output is design docs |

Other roles (QA, PM, reviewer, etc.) were deliberately dropped to keep the
data-collection loop clean.

## 6. Criterion 3 — other task criteria

These four factors are the "how" behind a story. Criterion 1 told you *how big* the story
is (base tokens), Criterion 2 who does it (R). This criterion adjusts for *where it runs*
(C), *how the agent operates* (M), *how messy it is* (H), and *how optimized your setup
is* (O). Each is an independent multiplier, so you can reason about them one at a time.

### C — codebase / context factor (input only)

| Codebase | C | Why |
|---|---|---|
| small (<10 files, single module) | 0.8 | agent stays inside a handful of files |
| medium (single repo, familiar) | 1.0 | baseline |
| large (monorepo / many services) | 1.5 | grep/reads pull in cross-module context |
| very large or unfamiliar | 2.0 | orientation dominates; every query is bigger |

**Example:** the same L-story on a 5-file module (C=0.8) reads 1,080k input, but on a
monorepo (C=1.5) it reads 2,025k — nearly double, purely because the agent has to reach
across more code to answer each question. C applies to **input only**; writing (output)
does not grow with repo size.

### M — modality factor

| Mode | M | Why |
|---|---|---|
| chat only (no tool execution) | 0.3 | one prompt, one reply, no tool dumps |
| editor completions + light agent | 0.6 | inline, short-lived context |
| agent mode (full tool use) | 1.0 | baseline agentic |
| agent + subagents | 1.2 | subagents each re-read shared context |
| agent + subagents + heavy MCP | 1.5 | MCP tool schemas + outputs inflate every turn |

**Example:** the same bug fix in chat (M=0.3) reads ~30k input; in agent mode (M=1.0)
reads ~100k; with subagents (M=1.2) ~120k. The **same code change** consumes ~4× more
tokens in agent mode than in chat — this is the single most common way estimates drift.

### H — rework / ambiguity factor (start at 1.0, add)

| Signal | Add |
|---|---|
| >6 acceptance criteria | +0.2 |
| ambiguous requirements / novel domain | +0.2 |
| flaky tests / cross-team dependencies | +0.3 |
| long feedback loops (deploy-heavy) | +0.3 |
| **Cap** | **1.5** |

**Example:** a story with 7 ACs and flaky tests (H = 1.0+0.2+0.3 = 1.5) reads 450k → 675k
input. H models **extra round-trips** — every failed attempt, re-read, and retry
multiplies the whole session, not just one phase.

### O — optimization factor (reward points)

Each installed technique earns **reward points** (report §9 ledger, max 43):
`O = 1 − 0.01 × points`, floor 0.50.

| Configuration | Points | O | Effective reduction |
|---|---|---|---|
| none | 0 | 1.00 | 0% |
| basic (AGENTS.md + ignore files) | 5 | 0.95 | 5% |
| standard (… + skills + compaction) | 13 | 0.87 | 13% |
| good (… + hooks + style skill) | 25 | 0.75 | 25% |
| full stack (… + symbol MCP + memory) | 40 | 0.60 | 40% |

**Example:** a "good" stack (O=0.75) on an M-story cuts 450k → 337k input. But note the
floor: even a perfect stack cannot take a 1,350k L-story below 675k — optimization is the
**final adjustment**, never a substitute for sizing the story correctly.

**Combined example (all four factors):** an M-story (450k/50k base), architect (R=1.4),
large monorepo (C=1.5), agent+subagents (M=1.2), ambiguous (H=1.2), good stack (O=0.75):

```
Input  = 450 × 1.4 × 1.5 × 1.2 × 1.2 × 0.75 = 1,021k
Output =  50 × 1.4 ×       1.2 × 1.2 × 0.75 =    76k
```

Same story, developer/medium/chat/no-opt (all 1.0): 450k/50k. The factors compound —
role, context, and modality are why two teams can "both do M-stories" and see 2× token
differences.

## 7. Monthly token demand

Estimate each story with the model, then sum by level:

```
Monthly_tokens = Σ per level  ( P50_story_tokens  × stories_that_month )
```

**Worked example** (developer, medium repo, agent mode, no optimization — runnable as
`python3 token-demand-estimator.py --monthly "S=10,M=20,L=5,XL=1"`):

| Level | Stories | Tokens/story (k) | Line tokens (M) |
|---|--:|--:|--:|
| S | 10 | 111 | 1.1 |
| M | 20 | 500 | 10.0 |
| L | 5 | 1,495 | 7.5 |
| XL | 1 | 5,550 | 5.6 |
| **Month total** | **36** | | **24.1** |

A 5-developer team at the same mix → **~120M tokens/month**.

**Top-down cross-check:** ~4M tokens per heavy active developer-day (§4 #1).
`monthly_tokens ≈ active_days × 4M × users`. If bottom-up and top-down disagree by more
than 2×, re-check the story mix and modality assumptions.

> Compute the monthly table directly with
> `python3 token-demand-estimator.py --monthly "S=10,M=20,L=5,XL=1"` (add `--opt good`
> to match your profile); the calibration form's monthly panel does the same live.

## 8. Worked examples

### Example 1 — Developer, S story (bug fix, 2 SP), medium repo, agent mode, no optimization

```
Base in 100k, out 11k           (111k total tokens)
R=1.0  C=1.0  M=1.0  H=1.0  O=1.0
Input ≈ 100k · Output ≈ 11k
Total ≈ 111k tokens
```

### Example 2 — Architect, L story (new service design, 8 SP), large repo, agent+subagents

```
Base in 1350k, out 145k
R=1.4  C=1.5  M=1.2  H=1.0  O=1.0
Input ≈ 1350 × 1.4 × 1.5 × 1.2 = 3402k · Output ≈ 145 × 1.4 × 1.2 = 244k
Total ≈ 3.6M tokens     (P10 2.4M – P90 4.9M)
```

Architect + L story + large repo is ~33× a developer + S story in tokens (3.6M vs 111k).
This is the profile that justifies architectural-level optimization.

### Example 3 — Developer, M story (3–5 SP) with a **good optimization stack**

```
Base in 450k, out 50k
R=1.0  C=1.0  M=1.0  H=1.3 (6+ AC)  O=0.75 (25 pts)
Input ≈ 450 × 1.3 × 0.75 = 439k · Output ≈ 50 × 1.3 × 0.75 = 49k
Total ≈ 488k tokens     vs unoptimized ≈ 500k
```

The optimization stack (rtk/squeez hooks + style skill + symbol MCP + memory) pays for
itself in the first few M+ stories.

### Sprint budget example (developer/architect mix)

| Story | SP | Role | Mode | Est. tokens (k) |
|------:|:--:|------|------|------:|
| Fix login validation | 2 | Developer | agent | 111 |
| Add export endpoint | 5 | Developer | agent+sub | 600 |
| Design auth service | 8 | Architect | agent+sub | 3,646 |
| **Sprint total (1 user)** | 15 | | | **~4,360** |

*(Architect row assumes a large repo, C = 1.5 — matches report §11 Scenario B.)*

## 9. Calibration loop (the part that makes it *accurate*)

The framework is a starting model; fit it to reality with a measurement loop. The loop
turns "the docs said ~111k for an S-story" into "our S-stories actually run ~130k".

1. **Log actuals per story.** Record: story ID, points, role, mode, optimization level,
   actual input tokens, actual output tokens. (The calibration form
   `docs/token-usage-data-form.html` logs this row live and exports CSV.)
2. **Source actuals from the tools you already have:**
   - Copilot: the session context-window control for session token totals.
   - rtk: `rtk gain --all --format json` (bash-output savings).
   - snip: `/snip-gain` (NET input savings).
   - claude-mem: session observations; context-mode: `ctx-stats`.
3. **After 5–10 stories**, recompute the Base table: for each complexity level,
   `Base_input = median(actual input)` and the same for output.
4. **Re-derive R per role** as `median(role_actual) / median(developer_actual)`.
5. Re-run forecasts; the low–high band should tighten each cycle.

**Worked mini-example (6 logged stories):**

| Story | Points | Role | Actual input (k) | Actual output (k) |
|---|:--:|:--:|--:|--:|
| JIRA-101 | 1 | developer | 95 | 10 |
| JIRA-102 | 2 | developer | 130 | 15 |
| JIRA-103 | 1 | developer | 88 | 9 |
| JIRA-104 | 2 | developer | 142 | 17 |
| JIRA-105 | 8 | architect | 1,900 | 210 |
| JIRA-106 | 8 | architect | 2,100 | 230 |

- `Base_input(S)` re-fit = median(95, 130, 88, 142) = **113k** (default was 100k) → the
  model's S-row is updated to 113k for the next forecast.
- `Base_input(L)` re-fit = median(1,900, 2,100) = **2,000k** (default 1,350k). The sample
  is small and possibly a C=1.5 large-repo story mis-logged without C; that is *exactly*
  why the rule is **5–10 stories minimum per cell** — one mis-labeled row skews a 2-row
  median.
- `R(architect)` = P50(arch input at L) / P50(dev input at S or M) — **compare like with
  like**: only re-derive R from stories at the same level, or the ratio mixes complexity
  with role.

> Fit on **tokens**. Tokens are the durable measure; they carry no pricing baggage.

**Template row** (copy to a sheet): `story_id | points | level | role | mode | opt | H | actual_in | actual_out | Δ forecast vs actual`.

## 10. Honest limitations

- **±50% band.** This is an estimation framework, not a meter. Report ranges. *Example:*
  the S-story central is 111k total but P90 is 156k — a 40% overshoot is normal variance,
  not a bug. Budget against P90, plan against P50.
- **Sessions are lumpy.** A single very large file read or a `pytest -v` dump can exceed a
  whole phase's budget; optimization factors exist precisely to cap these. *Example:* one
  `@`-mention of a 5,000-line generated file is ~200k tokens — more than the whole Verify
  phase.
- **Modality is behavioral.** The gap between chat and MCP-heavy agent use is the biggest
  single swing (5×); measure your real mix, don't assume.
- **Brevity ≠ cheap.** Aggressive style skills can trade correctness (see context-mode's
  kimi-k2.5 note); the H factor should absorb regression-fix loops. *Example:* a style
  skill that cuts output 65% may save 65% of output tokens but cause a 3-turn fix loop that
  costs more — net loss.
- **Two roles only.** Developer and architect are the calibration roles; other roles were
  deliberately dropped to keep the data-collection loop clean. *Implication:* for a PM or
  QA-heavy task, use the developer factors and a wider band rather than inventing a new
  role factor.

## 11. Quick-reference steps

1. Classify story → complexity level → Base in/out (Section 4).
2. Pick role → R: developer 1.0 / architect 1.4 (Section 5).
3. Adjust C, M, H, O (Section 6).
4. Apply model (Sections 3, 6).
5. Report low / central / high (tokens).
6. Log actuals and recalibrate after 5–10 stories (Section 9).
7. For a month: sum per-level tokens × story counts (Section 7) — or run
   `--monthly "S=10,M=20,L=5,XL=1"`.
