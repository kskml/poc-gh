#!/usr/bin/env python3
"""
GitHub Copilot token-demand estimator for agentic coding tasks.

Implements docs/token-demand-analysis-report.md (v3.1):

    Input_tokens   = Base_input(complexity) x R x C x M x H x O
    Output_tokens  = Base_output(complexity) x R x M x H x O
    Billed_input   = Input_tokens x (cache x 0.10 + (1 - cache))
    Cost           = Billed_input x P_in + Output_tokens x P_out
    O              = 1 - 0.01 x points        (optimization reward points, floor 0.50)
    AI credits     = Cost x 100               (1 GitHub AI credit = $0.01)

Token estimates are the durable output; cost/credits are re-computed at the pricing step.

Examples:
    python3 token-demand-estimator.py --level M --role developer              # ~450k input, ~149 credits
    python3 token-demand-estimator.py --level L --role architect --repo large --mode agent-subagents
    python3 token-demand-estimator.py --level M --points 25 --cache 0.7       # good optimization
    python3 token-demand-estimator.py --level M --role developer --json
    python3 token-demand-estimator.py --monthly "S=10,M=20,L=5,XL=1" --opt good   # monthly demand
"""
import argparse
import json

# Base token budgets (thousands) per Jira story complexity level - single-point estimates.
# "Turns" = one agent prompt->response round-trip; realistic values are small for tiny
# tasks (a typo fix is 1-3 turns) and grow with session size.
BASE = {
    "XXS": {"sp": "0.5", "turns": 2,    "input": 10,     "output": 2},
    "S":   {"sp": "1-2", "turns": 9,    "input": 100,    "output": 11},
    "M":   {"sp": "3-5", "turns": 38,   "input": 450,    "output": 50},
    "L":   {"sp": "8",   "turns": 90,   "input": 1350,   "output": 145},
    "XL":  {"sp": "13+", "turns": 275,  "input": 5000,   "output": 550},
}

# Role factors (only the two calibration roles)
# Architect reads more per turn but does far fewer turns and less rework,
# so net tokens on the same story are ~20% lower than a developer.
ROLE = {
    "developer": 1.0,
    "architect": 0.8,
}
# Codebase / context factor (input only)
CONTEXT = {"small": 0.8, "medium": 1.0, "large": 1.5, "huge": 2.0}
# Modality factor
MODALITY = {
    "chat": 0.3, "editor": 0.6, "agent": 1.0,
    "agent-subagents": 1.2, "agent-heavy": 1.5,
}
# Optimization presets (points -> O)
OPT_PRESETS = {
    "none": 0, "basic": 5, "standard": 13, "good": 25, "full": 40,
}
# GitHub Copilot model pricing: input, output, cache-read (all $/MTok)
# (per docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing)
TIER = {
    "sonnet": {"in": 3.00, "out": 15.00, "cache": 0.30, "label": "Claude Sonnet 4"},    # baseline (Copilot Versatile)
    "haiku":  {"in": 1.00, "out": 5.00,  "cache": 0.10, "label": "Claude Haiku 4.5"},   # Copilot Lightweight
    "opus":   {"in": 5.00, "out": 25.00, "cache": 0.50, "label": "Claude Opus 4.5"},    # Copilot Powerful
}
CACHE_DISCOUNT = 0.10          # cache reads billed at ~10% of input price
O_FLOOR = 0.50                 # minimum optimization factor
CREDIT_PER_USD = 100           # GitHub Copilot: 1 AI credit = $0.01
# Copilot plan monthly AI-credit allowances (for monthly projection)
PLAN_CREDITS = {"Pro": 1500, "Pro+": 7000, "Max": 20000}


def o_from_points(points: float) -> float:
    return max(1.0 - 0.01 * points, O_FLOOR)


def compute(level, role, repo, mode, points, tier, cache, rework):
    b = BASE[level]
    r, c, m, o = ROLE[role], CONTEXT[repo], MODALITY[mode], o_from_points(points)
    t = TIER[tier]

    in_k = b["input"] * r * c * m * o * rework
    out_k = b["output"] * r * m * o * rework
    billed_in = in_k * (cache * CACHE_DISCOUNT + (1 - cache))
    cost_in = billed_in * t["in"] / 1000.0
    cost_out = out_k * t["out"] / 1000.0
    total_cost = cost_in + cost_out
    result = {
        "turns": round(b["turns"], 1),
        "input_k": round(in_k),
        "output_k": round(out_k),
        "total_k": round(in_k + out_k),
        "billed_input_k": round(billed_in),
        "cost_usd": round(total_cost, 2),
        "credits": round(total_cost * CREDIT_PER_USD),
    }
    return {
        "level": level, "role": role, "model": tier, "factors": {
            "role_r": r, "context_c": c, "modality_m": m,
            "optimization_points": points, "opt_o": o, "rework_h": rework, "cache": cache,
        },
        "tier": tier, "estimate": result,
    }


def render_table(data):
    f = data["factors"]
    model = TIER[data["tier"]]["label"]
    print("=" * 92)
    print(f"GitHub Copilot token-demand estimate   level={data['level']:<3} role={data['role']:<10} model={model}")
    print(f"   R={f['role_r']:.2f}  C={f['context_c']:.2f}  M={f['modality_m']:.2f}  "
          f"H={f['rework_h']:.2f}  O={f['opt_o']:.2f} ({f['optimization_points']} pts)  cache={f['cache']:.0%}")
    print("=" * 92)
    print(f"{'estimate':<9}{'turns':>8}{'input(k)':>11}{'output(k)':>11}{'total(k)':>11}{'billed_in(k)':>14}{'credits':>10}")
    print("-" * 92)
    s = data["estimate"]
    print(f"{'estimate':<9}{s['turns']:>8.0f}{s['input_k']:>11,}{s['output_k']:>11,}"
          f"{s['total_k']:>11,}{s['billed_input_k']:>14,}{s['credits']:>10,}")
    print("=" * 92)
    print("90/10 rule: ~90% of tokens are input; total session tokens ~= 1.1 x input.")
    print("Tokens are the durable estimate; credits = cost x 100 (1 AI credit = $0.01).")


def monthly_projection(counts, role, repo, mode, points, tier, cache, rework):
    """Project one month of story counts -> tokens, credits, cost, plan fit.

    counts: dict {level: number_of_stories} e.g. {"S":10,"M":20,"L":5,"XL":1}
    Returns a dict; prints a human-readable table as a side effect (omit by
    calling monthly_data() directly).
    """
    data = monthly_data(counts, role, repo, mode, points, tier, cache, rework)
    model = TIER[tier]["label"]
    print("=" * 88)
    print(f"GitHub Copilot monthly projection    role={role:<10} model={model}  "
          f"opt={points} pts  cache={cache:.0%}")
    print("=" * 88)
    print(f"{'level':<6}{'stories':>9}{'input(k)':>11}{'output(k)':>11}{'total(k)':>11}{'credits':>10}{'cost($)':>10}")
    print("-" * 88)
    for row in data["rows"]:
        print(f"{row['level']:<6}{row['stories']:>9,}{row['input_k']:>11,}{row['output_k']:>11,}"
              f"{row['total_k']:>11,}{row['credits']:>10,}{row['cost_usd']:>10,.2f}")
    print("-" * 88)
    print(f"{'TOTAL':<6}{data['stories']:>9,}{data['total_in_k']:>11,}{data['total_out_k']:>11,}"
          f"{data['total_k']:>11,}{data['credits']:>10,}{data['cost_usd']:>10,.2f}")
    print("=" * 88)
    print(f"Monthly tokens: ~{data['total_k'] / 1000:.2f}M   cost: ~${data['cost_usd']:.2f}")
    print("Plan fit (1 user/month, AI credits):")
    for plan, allowance in PLAN_CREDITS.items():
        users = allowance / data["credits"] if data["credits"] else float("inf")
        print(f"  {plan:<5} {allowance:>6,} credits -> {'%.1f' % users} users at this load")
    return data


def monthly_data(counts, role, repo, mode, points, tier, cache, rework):
    """Pure computation for a month of stories; returns a dict (no printing)."""
    total_in = total_out = total_credits = 0.0
    rows = []
    for level, n in counts.items():
        d = compute(level, role, repo, mode, points, tier, cache, rework)
        s = d["estimate"]
        t_in, t_out, t_cred = s["input_k"] * n, s["output_k"] * n, s["credits"] * n
        total_in += t_in; total_out += t_out; total_credits += t_cred
        rows.append({"level": level, "stories": n, "input_k": t_in, "output_k": t_out,
                     "total_k": t_in + t_out, "credits": t_cred, "cost_usd": round(t_cred * 0.01, 2)})
    return {"rows": rows, "stories": sum(counts.values()),
            "total_in_k": total_in, "total_out_k": total_out, "total_k": total_in + total_out,
            "credits": total_credits, "cost_usd": round(total_credits * 0.01, 2),
            "plan_fit": {p: (a / total_credits if total_credits else float("inf"))
                         for p, a in PLAN_CREDITS.items()}}


def main():
    ap = argparse.ArgumentParser(description="Estimate GitHub Copilot token demand for a coding task (Claude Sonnet 4 baseline).")
    ap.add_argument("--level", choices=list(BASE), default="M", help="Jira story complexity level")
    ap.add_argument("--role", choices=list(ROLE), default="developer", help="role (developer or architect)")
    ap.add_argument("--repo", choices=list(CONTEXT), default="medium")
    ap.add_argument("--mode", choices=list(MODALITY), default="agent")
    ap.add_argument("--opt", choices=list(OPT_PRESETS), default=None, help="optimization preset")
    ap.add_argument("--points", type=float, default=None, help="optimization reward points (0-46); O = 1 - 0.01*points")
    ap.add_argument("--tier", choices=list(TIER), default="sonnet", help="Copilot model")
    ap.add_argument("--cache", type=float, default=0.5, help="cache hit rate (0-1)")
    ap.add_argument("--rework", type=float, default=1.0, help="rework/ambiguity factor (1.0-1.5)")
    ap.add_argument("--json", action="store_true", help="print JSON instead of table")
    ap.add_argument("--monthly", metavar="LEVEL=COUNT[,LEVEL=COUNT...]", default=None,
                    help="monthly story counts, e.g. --monthly 'S=10,M=20,L=5,XL=1'; prints a monthly projection")
    args = ap.parse_args()

    if args.points is None:
        points = OPT_PRESETS[args.opt] if args.opt else 0
    else:
        points = args.points

    if args.monthly:
        counts = {}
        for pair in args.monthly.split(","):
            level, _, n = pair.partition("=")
            level = level.strip().upper()
            if level not in BASE:
                ap.error(f"unknown level '{level}' in --monthly")
            counts[level] = int(n.strip())
        if args.json:
            print(json.dumps(monthly_data(counts, args.role, args.repo, args.mode,
                                          points, args.tier, args.cache, args.rework),
                             indent=2))
        else:
            monthly_projection(counts, args.role, args.repo, args.mode,
                               points, args.tier, args.cache, args.rework)
        return

    data = compute(args.level, args.role, args.repo, args.mode, points,
                   args.tier, args.cache, args.rework)
    if args.json:
        print(json.dumps(data, indent=2))
    else:
        render_table(data)


if __name__ == "__main__":
    main()
