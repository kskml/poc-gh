# AI Coding Assistant Token Demand Model — Beginner's Guide

> A plain-English, start-from-zero walkthrough of every concept in the token-demand docs.
> If you are new to this, read this file top to bottom — each section builds on the last,
> and every number is shown step by step.
>
> Scope: **token estimation only**. No credit/cost conversion anywhere.
> Baseline model: **Claude Sonnet 4** (any AI coding assistant).

---

## 1. What this is about (plain English)

An AI coding assistant (the tool that helps you write code) does not think in words — it
processes text in chunks called **tokens**. Every time it helps you, it reads tokens (your
question, your code files, its own output) and writes tokens (the answer, code edits).

Teams kept hitting one basic question with no answer:

> **"How many tokens will this Jira story cost the assistant — before we start it?"**

This guide answers that. It explains a simple **formula** that turns two things into a
token estimate:

1. **How big is the story?** (story points → a base number of tokens)
2. **How is the work actually run?** (who does it, what repo, which mode → a multiplier)

That's the whole idea. Everything below just makes those two parts precise.

---

## 2. What the numbers actually look like (start here)

An M-level story (a "medium" feature, 3–5 story points), done by a developer on a normal
repo in agent mode, with nothing special going on:

```
Input tokens   = 450k   (everything the assistant reads)
Output tokens  =  50k   (everything the assistant writes)
Total          = 500k tokens
```

**500k tokens ≈ 1.4 million English words.** That sounds enormous, but remember: the
assistant re-reads your code, tool output, and the conversation history on *every single
turn* of a session. A 38-turn session does not read 38 different things — it re-reads the
same context ~38 times. That is why the number grows so fast.

Throughout this guide we use the M-story as our example because it is the most common unit
of work. All numbers are **single estimates** (one number per story) — there are no
complicated ranges or percentiles to juggle.

---

## 3. Core concepts (each explained from zero)

### 3.1 Token

The smallest unit of text a model processes. Roughly **4 characters ≈ 1 token**.

| Phrase | Approx. tokens |
|---|---|
| `return true;` | ~4 |
| "Fix the login bug on the home page." | ~10 |
| A 1,000-line code file | ~8,000–12,000 |

Think of a token as the "cost per word" currency of the assistant. Every sentence you see in
its chat box is made of tokens behind the scenes.

### 3.2 Input tokens vs output tokens — the most important split

| Term | What it is | Real examples |
|---|---|---|
| **Input tokens** | everything the assistant **reads** | your question, the system prompt, the files it opens, tool output, the whole conversation history |
| **Output tokens** | everything the assistant **writes** | its reply, code it edits in, a design doc |

> **Key fact to remember for the whole guide:** a full session is almost all *reading*.
> ~90% of all tokens are input. You only see the output — but the assistant spent 9× more
> reading to produce it.

### 3.3 Turn and session

- **Turn** = one round trip: assistant reads your message → thinks → writes a reply.
  A session is made of many turns.
- **Session** = one continuous assistant conversation (one chat window from open to close).

```
Session = Turn 1 + Turn 2 + Turn 3 + ... + Turn N
```

| Story level | Typical turns |
|---|---|
| XXS (one-line fix) | ~2 |
| S (small bug fix) | ~9 |
| M (feature) | ~38 |
| L (new module) | ~90 |
| XL (epic) | ~275 |

Why turns matter: **each turn re-reads the context.** 38 turns × the same context = the
input number balloons. Fewer turns = fewer tokens, all else equal.

### 3.4 Story points and complexity levels

Jira sizes stories in **story points (SP)**. We map points to a complexity level:

| Level | Story points | Meaning | Typical example |
|---|---|---|---|
| XXS | 0.5 | trivial | fix a typo, flip a config toggle |
| S | 1–2 | small | single-file bug fix, one endpoint |
| **M** | 3–5 | medium | feature in 1–2 files with edge cases |
| L | 8 | large | new module, multi-file integration |
| XL | 13+ | epic | cross-service architecture |

> **"M5"** is shorthand for "an M-level story sized at 5 points" — the largest typical M.
> It is not a separate level; it just tells you how big within the M bucket.

### 3.5 Baseline model

All the base budgets in this guide assume **Claude Sonnet 4**. This is a *token* baseline:
the same token counts roughly apply no matter which model you use, because token counts
depend on the work, not the price list. **Model choice and pricing are out of scope here** —
they change what you pay, not how many tokens are read and written.

### 3.6 The 90/10 input rule

Across measured sessions, **~90% of tokens are input**:

```mermaid
pie showData
    title "Where tokens go in an M-story"
    "Input (what the assistant reads)" : 90
    "Output (what it writes)" : 10
```

**No-math way to check a session:** if the session window shows `input = 450k`, expect
`total ≈ 450k × 1.1 = 500k`. If the ratio is much higher (say 1.6×), the assistant is
re-reading huge context repeatedly — a sign to compress the input side, not a model error.

### 3.7 Story complexity → base token budget

Each complexity level has a **base input/output budget** (developer, agent mode):

| Level | Turns | Base input (k) | Base output (k) | Total (k) | Example |
|---|---|--:|--:|--:|---|
| XXS | 2 | 10 | 2 | 12 | typo, one-line fix |
| S | 9 | 100 | 11 | 111 | single-file bug fix |
| **M** | 38 | **450** | **50** | **500** | feature in 1–2 files |
| L | 90 | 1,350 | 145 | 1,495 | new module / integration |
| XL | 275 | 5,000 | 550 | 5,550 | epic, cross-service |

**Notice how fast it grows:**

- M = 500k, L = 1,495k → L is ~3× M.
- M = 500k, XL = 5,550k → XL is ~11× M.

This **super-linear** growth is the single biggest practical point: **getting "M vs L"
wrong changes your estimate ~3×.** Complexity misclassification is the #1 estimation error.
When unsure, size conservatively (round up).

### 3.8 Token anatomy — where tokens go inside one story

A story is not one big read. It is phases (developer, M-story):

| Phase | What the assistant does | Input (k) | Output (k) | Share of input |
|---|---|--:|--:|--:|
| Plan | read story, clarify, outline | 40 | 3 | 9% |
| **Explore** | search / read files | **150** | 2 | **33%** |
| Implement | write / edit code | 120 | 30 | 27% |
| Verify | run tests, read failures, fix | 80 | 8 | 18% |
| Review | self-review, refactor | 40 | 5 | 9% |
| Communicate | commit msg, PR description | 20 | 2 | 4% |
| **Total** | | **450** | **50** | 100% |

```mermaid
pie showData
    title "Input token anatomy - M story (450k)"
    "Explore" : 150
    "Implement" : 120
    "Verify" : 80
    "Plan" : 40
    "Review" : 40
    "Communicate" : 20
```

**Why this matters:** Explore is the biggest input sink (33%) — so symbol-level retrieval
and repo maps pay off there. Verify is the most compressible (18%) — test output shrinks
~90% when you capture it into files instead of pasting it. **Optimize the input side first**,
because that is where ~90% of tokens live.

---

## 4. The estimation formula (the heart of the model)

Two lines. Everything else in this guide is just defining the pieces:

```
Input_tokens   = Base_input(complexity) × R × C × M × H × O
Output_tokens  = Base_output(complexity) × R × M × H × O
```

Read it as: **start with the base budget for the story size, then multiply by the factors
that describe how the work is actually run.**

| Factor | Name | Values | Applies to |
|---|---|---|---|
| **R** | Role | developer 1.0 · architect **0.8** | input + output |
| **C** | Codebase / context | small 0.8 · medium 1.0 · large 1.5 · huge/unfamiliar 2.0 | **input only** |
| **M** | Modality | chat 0.3 · editor 0.6 · agent 1.0 | input + output |
| **H** | Rework / ambiguity | 1.0 base; +0.2; +0.3; cap 1.5 | input + output |
| **O** | Optimization | `O = 1 − 0.01 × points`, floor 0.50 | input + output |

### How to read the formula — three structural facts

1. **Everything is a multiplier, not an addition.** If rework doubles (H: 1.0 → 2.0, say),
   the *whole* estimate doubles. If you switch chat → agent mode (~3×), the whole estimate
   roughly triples. That is why small habits matter.
2. **C applies to input only.** Writing doesn't grow because the repo is bigger — reading
   does. So C only touches the input line.
3. **R, M, H, O apply to both** input and output.

```mermaid
graph TD
    A["Jira story points"] --> B["Complexity level XXS-XL"]
    B --> C["Base input + output tokens"]
    C --> D["Role R"]
    D --> E["Codebase C - input only"]
    E --> F["Modality M"]
    F --> G["Rework H"]
    G --> H["Optimization O"]
    H --> I["Estimated input + output tokens"]
```

### The meaning of a factor of 1.0

Every factor defaults to **1.0** = "no change." Multiplying by 1.0 does nothing, so if a
story is a normal case, you skip that factor entirely. You only multiply when the work is
*not* the baseline. This is what makes the model easy to audit: every non-1.0 factor is a
deliberate choice.

---

## 5. The five factors, explained one at a time

### 5.1 R — Role (who does the story)

| Role | Factor | What it means |
|---|---|---|
| **Developer** | 1.0 | The baseline: implements + tests, iterates a lot |
| **Architect** | 0.8 | Design work: reads more per turn, but does **fewer turns** and far less trial-and-error |

**Wait — architects are *cheaper*?** Yes, and this surprises people. Tokens = read × write
× round-trips. An architect knows the answer before asking, so the session ends sooner —
far fewer turns. A developer implementing the same story iterates more (re-read, test,
fix), which multiplies tokens. The extra *reading per turn* an architect does is easily
outweighed by having *far fewer turns*. Net: ~20% fewer tokens on the same story.

**How to pick:** classify by the *type of work*, not the job title.
- Code inside one module, following existing patterns → **Developer** (R = 1.0).
- A decision, a design, or cross-service change → **Architect** (R = 0.8).
- A staff engineer fixing a one-file bug is a Developer for that story.

### 5.2 C — Codebase / context (how much code gets read)

| Codebase | Factor | What it looks like |
|---|---|:---:|
| Small | 0.8 | <10 files, one module; the assistant stays inside a handful of files |
| Medium | 1.0 | Single repo, familiar (baseline) |
| Large | 1.5 | Monorepo / many services; every search pulls in cross-module context |
| Huge / unfamiliar | 2.0 | New or enormous codebase; orientation dominates every query |

**Example:** the same L-story reads 1,080k input on a small module but 2,025k on a monorepo
— nearly double, purely because each question reaches across more code. Note C only changes
the **input** line; you don't write more code just because the repo is bigger.

### 5.3 M — Modality (how the assistant runs)

| Mode | Factor | What it looks like |
|---|---|:---:|
| Chat only (no tool execution) | 0.3 | You paste code and ask; one prompt, one reply |
| Editor completions + light agent | 0.6 | Inline suggestions while you type |
| Agent mode (full tool use) | 1.0 | The assistant reads files and runs tools itself (baseline) |

**Example:** the same bug fix is ~30k input in chat but ~100k in agent mode. **Agent mode
costs ~3× more tokens than chat for the same change** — the single most common way estimates
drift. Agent mode is the baseline because it is how most real work runs; treat chat as the
exception, not the rule.

### 5.4 H — Rework / ambiguity (how many attempts)

Rework means **the assistant does the work more than once** because the target kept moving.
Every retry re-reads the same context, so rework multiplies the whole session.

| Signal | Add to H | Real example |
|---|---|:---:|
| >6 acceptance criteria | +0.2 | "filter, sort, export, and get notified" — lots of branches to keep in context |
| Ambiguous requirements / novel domain | +0.2 | "handle errors gracefully" without saying what that means |
| Flaky tests / cross-team dependencies | +0.3 | random test failures make the assistant chase phantom bugs |
| Long feedback loops (deploy-heavy) | +0.3 | a 15-minute deploy per check makes every wrong guess expensive |
| **Cap** | **1.5** | above this, re-estimate the story instead |

**Example:** a clean M-story costs ~500k. The same story with vague requirements *and* flaky
tests (H = 1.0 + 0.2 + 0.3 = 1.5) costs ~750k — a 50% surcharge from rework alone.

### 5.5 O — Optimization (efficiency techniques)

Optimization makes the assistant's *context cheaper* — fewer redundant tokens per turn, less
re-reading, tighter outputs. Each technique earns **points**; more points = smaller O.

```
O = 1 − 0.01 × points      (never below 0.50)
```

| Configuration | Points | O | Reduction | What you actually install |
|---|:---:|:---:|:---:|---|
| None | 0 | 1.00 | 0% | nothing |
| Basic | 5 | 0.95 | 5% | project rules file (AGENTS.md) + ignore files |
| Standard | 13 | 0.87 | 13% | Basic + skills/commands + context compaction |
| Good | 25 | 0.75 | 25% | Standard + output hooks + a style/format skill |
| Full stack | 40 | 0.60 | 40% | Good + symbol-level retrieval + persistent memory |

**Why the floor is 0.50:** even a perfect setup must still read the story and write the
answer. Optimization halves, never eliminates.

**Where optimization helps most:** input-heavy, turn-heavy work (L/XL stories, big repos,
agent mode) — that is where the redundant context lives. A short chat-style S-story has
little to reclaim.

> **Honest framing:** the full stack removes 40% of tokens, but getting M vs L wrong changes
> the estimate ~3×. **Optimization is the final polish — it never fixes a wrong-size
> estimate.** Right-size the story first.

---

## 6. Worked examples (everything, step by step)

### 6.1 Example 1 — the plain M-story (no factors change)

Developer, medium repo, agent mode, clean story, no optimization — every factor is 1.0:

```
Input   = 450 × 1.0 × 1.0 × 1.0 × 1.0 × 1.0 = 450k
Output  =  50 × 1.0 × 1.0 × 1.0 × 1.0 × 1.0 =  50k
Total   = 500k tokens
```

Because every factor is 1.0, this is just the base budget. This is the "nothing special"
case every other example is compared against.

### 6.2 Example 2 — same story, but an architect does it

Change only R from 1.0 to 0.8:

```
Input   = 450 × 0.8 = 360k
Output  =  50 × 0.8 =  40k
Total   = 400k tokens
```

**400k vs 500k — the architect is 20% cheaper.** Same story, same repo, same mode. The only
difference is fewer, more decisive turns. Role is the one factor that can move an estimate
*below* its baseline.

### 6.3 Example 3 — all five factors at once (trace each step)

M-story (450k/50k base), architect (R=0.8), large monorepo (C=1.5), agent mode (M=1.0),
ambiguous (H=1.2), good stack (O=0.75):

```
Step 0 — start from the base budgets:      Input = 450k   Output = 50k

Step 1 — R (architect):                    Input = 360k   Output = 40k
Step 2 — C (large repo, input only):       Input = 540k   Output = 40k   ← C skipped on output
Step 3 — M (agent mode, already baseline): Input = 540k   Output = 40k
Step 4 — H (ambiguous, +0.2):              Input = 648k   Output = 48k
Step 5 — O (good stack):                   Input = 486k   Output = 36k

Final:  486k + 36k = 522k tokens
```

**Trace check:** did Step 2 skip output? Yes — C applies to input only, so output stayed 40k
in Step 2. Everything else applied to both lines. Each step is one factor, in one table.

**Why is this *bigger* than Example 2 (400k)?** Example 2 was architect on a *medium* repo
with *clean* requirements. This one adds a **large repo (C=1.5)** and **ambiguous
requirements (H=1.2)**. The extra 122k is repo size + rework, **not** the architect role.

### 6.4 Example 4 — apples-to-apples: role only, same everything

The same M-story on a medium repo, clean requirements, agent mode, good stack — only role
differs:

```
Developer:  Input = 450 × 0.75 = 338k     Output = 50 × 0.75 = 38k     Total = 375k
Architect:  Input = 360 × 0.75 = 270k     Output = 40 × 0.75 = 30k     Total = 300k
```

| Who | Total |
|---|---|
| Developer | 375k |
| Architect | **300k** (20% less) |

**This is the fair comparison.** Never compare an architect on a huge monorepo against a
developer on a small repo and blame the role — the difference was repo size and rework.

### 6.5 Example 5 — three end-to-end scenarios

**Scenario A — Developer, S story (bug fix), medium repo, agent mode**

```
Input   = 100k
Output  =  11k
Total   = 111k tokens
```

**Scenario B — Architect, L story (new service), large repo, agent mode**

```
Input   = 1,350 × 0.8 × 1.5 = 1,620k
Output  = 145 × 0.8 = 116k
Total   = 1.7M tokens
```

Scenario B is ~15× Scenario A. The driver is **complexity (L) and repo size (C=1.5)** — the
architect role (0.8) actually *reduces* the number.

**Scenario C — Developer, M story, ambiguous (H=1.3), good optimization (O=0.75)**

```
Input   = 450 × 1.3 × 0.75 = 439k
Output  =  50 × 1.3 × 0.75 =  49k
Total   = 488k tokens   (vs the plain M-story: 500k)
```

**Only ~2% fewer tokens!** Rework (+30%) almost cancels the optimization (−25%). This is
the key lesson: **optimize *and then measure*, don't assume.** If the story is ambiguous,
no amount of optimization saves you — fix the requirements first.

### 6.6 Example 6 — monthly rollup

Estimate each story, then sum per level:

```
Monthly_tokens = sum over levels of ( tokens_per_story × stories_that_month )
```

| Level | Stories | Tokens/story | Line total |
|---|--:|--:|--:|
| S | 10 | 111k | 1.1M |
| M | 20 | 500k | 10.0M |
| L | 5 | 1,495k | 7.5M |
| XL | 1 | 5,550k | 5.6M |
| **Month total** | **36** | | **~24.1M** |

**Cross-check:** a heavy developer-day ≈ 4M tokens, so
`monthly ≈ active_days × 4M × users`. If bottom-up and top-down disagree by >2×, your story
mix or factor assumptions are off. A **5-developer team at the same mix ≈ 120M/month**.

**What optimization changes here:** with the good stack (O = 0.75) on every story, the
24.1M month becomes **~18.1M** — a ~6M saving from one factor.

---

## 7. Sensitivity — which lever actually moves the number

One factor moved at a time, developer M-story (500k):

| Factor | Low | High | Tokens low | Tokens high | Swing |
|---|---|---|--:|--:|:--:|
| Role R | architect 0.8 | developer 1.0 | 400k | 500k | 1.25× |
| Context C | small 0.8 | huge 2.0 | 410k | 950k | 2.3× |
| **Modality M** | chat 0.3 | agent 1.0 | 150k | 500k | **3.3×** |
| Rework H | 1.0 | 1.5 | 500k | 750k | 1.5× |
| Optimization O | none 1.0 | full 0.60 | 500k | 300k | 1.7× |

```mermaid
xychart-beta
    title "Token swing by factor (developer M-story, 500k)"
    x-axis ["Role","Context","Modality","Rework","Optimization"]
    y-axis "Swing (x)" 0 --> 4
    bar [1.25,2.3,3.3,1.5,1.7]
```

**Takeaways for a beginner:**

- **Modality is the biggest lever (3.3×).** The same change costs ~3× more tokens in agent
  mode than chat. Match the mode to the job.
- **Context (2.3×) and optimization (1.7×)** are the next biggest. Big repos cost a lot;
  good optimization reclaims a lot.
- **Role (1.25×)** and **rework (1.5×)** are smaller but free or cheap to get right.
- **Optimization can offset rework:** a good stack cuts an ambiguous session roughly back to
  its clean baseline.

---

## 8. Ground truth — where to get real numbers

| What you want | Where to find it |
|---|---|
| Session token totals | Session context-window control in the agent |
| Per-turn token usage | Hover a chat response |
| Saved bash output | rtk: `rtk gain --all --format json` |
| Saved input tokens | snip: `/snip-gain` |
| Session observations | claude-mem: `ctx-stats` |

---

## 9. Calibration loop — how the model learns your team

The base table and role factors are **starting guesses**. Re-fit them from your own real
sessions every 5–10 stories per level.

```mermaid
graph LR
    A["Log actuals per story"] --> B["Source from the assistant / telemetry"]
    B --> C["Recompute Base_input = median per level"]
    C --> D["Re-derive R per role"]
    D --> E["Re-fit - estimate aligns with reality"]
```

**How to log a story:** `story_id | points | level | role | mode | opt | H | actual_in |
actual_out`. The browser form does this for you and exports CSV.

**Worked example — re-fitting the S row.** Log 8 real S-stories (developer, agent mode):

```
Actual inputs (k):  95, 130, 88, 142, 105, 118, 97, 122
Sorted:             88, 95, 97, 105, 118, 122, 130, 142
Median = (105 + 118) / 2 = 111.5k    → the default was 100k
```

Update the S base input from 100k to ~112k. Small drift — the starting guess was fine. Now
4 architect S-stories:

```
Actual inputs (k):  95, 80, 110, 72   → median = 87.5k
Re-derived R(architect) = 87.5 / 111.5 = 0.78   → the default was 0.8
```

0.78 is close to 0.8, but 4 samples is few — **that is why the rule is 5–10 stories
minimum.** With 4 you adjust cautiously; with 10 you commit.

> **Why medians, not averages:** one monster session (a giant generated file) can inflate an
> average 2×. The median ignores the outlier and tracks the typical story.

---

## 10. How to use the tools

### CLI (`token-demand-estimator.py`)

```bash
# Single story estimate (tokens)
python3 token-demand-estimator.py --level M --role developer

# With optimization points and a monthly projection
python3 token-demand-estimator.py --level M --points 25
python3 token-demand-estimator.py --monthly "S=10,M=20,L=5,XL=1"

# JSON output for scripting
python3 token-demand-estimator.py --level L --role architect --json
```

### Form (`token-usage-data-form.html`)

1. **Estimate a story:** pick a size — total/input/output tokens are generated live.
2. **Log a story (optional):** add real actuals; the delta is computed automatically.
3. **This month:** enter S/M/L/XL counts for a monthly token projection.
4. Everything saves in your browser; use **Export CSV** to share/recalibrate.

---

## 11. Honest limitations

1. **A single estimate, not a guarantee.** Real sessions vary — one giant file read can
   exceed the estimate. Add a 20–30% buffer when budgeting capacity.
2. **Lumpy sessions.** A single 5,000-line generated file ≈ 200k tokens can blow a whole
   phase's budget.
3. **Modality is behavioral.** The chat → agent gap is 3.3×; measure your real mix.
4. **Brevity can trade correctness.** Aggressive style skills may cause a 3-turn fix loop
   that costs more — net loss.
5. **Two roles only.** For QA/PM-heavy work, use developer factors with a slightly larger
   buffer rather than inventing a new role.
6. **Baseline-dependent.** Budgets are calibrated to Claude Sonnet 4; the docs make no claim
   about pricing or billing.

---

## 12. One-paragraph summary (the elevator pitch)

Token demand in an AI coding assistant is a product of *how much it reads*, *how much it
writes*, and *how many round-trips it takes*. The model encodes that as
`Input = Base(complexity) × R × C × M × H × O` (and a similar line for output), calibrated
to a Claude Sonnet 4 baseline. ~90% of tokens are input, Explore is the biggest sink,
modality is the biggest lever (3.3×), complexity misclassification is the biggest error, and
architects are *cheaper* per same-size story (R = 0.8) because they take fewer turns. The
model produces one simple estimate per story, rolls those up into monthly budgets, and gives
you a calibration loop to re-fit it to your team's real usage — entirely in tokens.
